/*******************************************************************************
**This file include a series of functions for binary heap and leftiest heap
*******************************************************************************/

/*******************************************************************************
**The following functions are used for binary heap operations
*******************************************************************************/

//Data structure for binary heap 
struct Binary_Heap
{  
  Struct_Edge *Stored_Edge;
  int Heap_Length;
};

//Allocate memory for binary heap 
bool Creat_Binary_Heap(Binary_Heap *Cur_Heap,int Max_Heap_Length)
{ 
  Cur_Heap->Stored_Edge=NULL; 
  Cur_Heap->Stored_Edge=new Struct_Edge[Max_Heap_Length];   
  Cur_Heap->Heap_Length=0;  
   
  if(Cur_Heap->Stored_Edge==NULL)
  {
    printf("Creat_Binary_Heap() fail! Fail to allocate memory.\n");
    getchar();
    return false; 
  }
  return true;
}//End Creat_Binary_Heap()

//Clear binary heap
void Clear_Binary_Heap(Binary_Heap *Cur_Heap)
{
  Cur_Heap->Heap_Length=0;
}//End Clear_Binary_Heap()

//Delete a binary heap and release the occupied memory 
void Delete_Binary_Heap(Binary_Heap *Cur_Heap)
{
  delete []Cur_Heap->Stored_Edge;  
  //delete Cur_Heap;
}//End Delete_Binary_Heap()

//Delete a binary heap and release the occupied memory 
void Delete_Binary_Heap(Binary_Heap Cur_Heap)
{
  delete []Cur_Heap.Stored_Edge;  
  //delete &Cur_Heap;
}//End Delete_Binary_Heap()

//Swap two edges of a binary heap 
void Binary_Heap_Swap_Edges(Binary_Heap *Cur_Heap,int First_Edge_Pos,int Second_Edge_Pos)
{
  int Temp_First_Vtx=Cur_Heap->Stored_Edge[First_Edge_Pos].First_Vtx;
  int Temp_Second_Vtx=Cur_Heap->Stored_Edge[First_Edge_Pos].Second_Vtx;
  Cost_Type Temp_Cost=Cur_Heap->Stored_Edge[First_Edge_Pos].Cost;
  
  Cur_Heap->Stored_Edge[First_Edge_Pos].First_Vtx  = Cur_Heap->Stored_Edge[Second_Edge_Pos].First_Vtx;  
  Cur_Heap->Stored_Edge[First_Edge_Pos].Second_Vtx = Cur_Heap->Stored_Edge[Second_Edge_Pos].Second_Vtx;
  Cur_Heap->Stored_Edge[First_Edge_Pos].Cost       = Cur_Heap->Stored_Edge[Second_Edge_Pos].Cost;
  
  Cur_Heap->Stored_Edge[Second_Edge_Pos].First_Vtx=Temp_First_Vtx;
  Cur_Heap->Stored_Edge[Second_Edge_Pos].Second_Vtx=Temp_Second_Vtx;
  Cur_Heap->Stored_Edge[Second_Edge_Pos].Cost=Temp_Cost;   
}//End Binary_Heap_Swap_Edges() 

//Move up an edge until it meets the heap definition 
void Binary_Heap_Move_Up(Binary_Heap *Cur_Heap,int Edge_Pos)
{    
  int Child_Pos=Edge_Pos;
  int Parent_Pos=(Child_Pos-1)/2;
  while(Child_Pos>0 && Cur_Heap->Stored_Edge[Child_Pos].Cost<Cur_Heap->Stored_Edge[Parent_Pos].Cost)
  {
    Binary_Heap_Swap_Edges(Cur_Heap,Child_Pos,Parent_Pos); 
    Child_Pos=Parent_Pos; 
    Parent_Pos=(Child_Pos-1)/2; 
  }
}//End Binary_Heap_Move_Up() 

//Move down an edge until it meets the heap definition
void Binary_Heap_Move_Down(Binary_Heap *Cur_Heap,int Edge_Pos)
{
  int Parent_Pos=Edge_Pos;
  while(true)
  {
    int Left_Child_Pos=2*Parent_Pos+1;
    int Right_Child_Pos=2*Parent_Pos+2;
    
    int Min_Child_Pos=Null;    
    if(Left_Child_Pos <= Cur_Heap->Heap_Length-1)
      Min_Child_Pos=Left_Child_Pos;
    if(Right_Child_Pos <= Cur_Heap->Heap_Length-1 
      && Cur_Heap->Stored_Edge[Right_Child_Pos].Cost<Cur_Heap->Stored_Edge[Left_Child_Pos].Cost)
      Min_Child_Pos=Right_Child_Pos;    
    
    if(Min_Child_Pos==Null || Cur_Heap->Stored_Edge[Parent_Pos].Cost <= Cur_Heap->Stored_Edge[Min_Child_Pos].Cost)
      break;
    
    Binary_Heap_Swap_Edges(Cur_Heap,Parent_Pos,Min_Child_Pos);
    Parent_Pos=Min_Child_Pos;                                        
  } 
}//End Binary_Heap_Move_Down()

//Add a new edge to the binary heap and adjust it to meet heap definition 
void Binary_Heap_Add_Edge(Binary_Heap *Cur_Heap,int First_Vtx,int Second_Vtx,Cost_Type Edge_Cost)
{ 
  Cur_Heap->Stored_Edge[Cur_Heap->Heap_Length].First_Vtx=First_Vtx;
  Cur_Heap->Stored_Edge[Cur_Heap->Heap_Length].Second_Vtx=Second_Vtx;
  Cur_Heap->Stored_Edge[Cur_Heap->Heap_Length].Cost=Edge_Cost;
  Cur_Heap->Heap_Length++;
  
  Binary_Heap_Move_Up(Cur_Heap,Cur_Heap->Heap_Length-1);
}//End Binary_Heap_Add_Edge() 

//Get the top edge index of the heap (return First_Vtx*Real_Vtx_Num+Second_Vtx)
int Binary_Heap_Extract_Min_Edge(Binary_Heap *Cur_Heap,int Real_Vtx_Num)
{
  if(Cur_Heap->Heap_Length<=0)
    return Null; 
      
  int Min_Edge_Index=Cur_Heap->Stored_Edge[0].First_Vtx*Real_Vtx_Num+Cur_Heap->Stored_Edge[0].Second_Vtx;

  Cur_Heap->Stored_Edge[0].First_Vtx=Cur_Heap->Stored_Edge[Cur_Heap->Heap_Length-1].First_Vtx;
  Cur_Heap->Stored_Edge[0].Second_Vtx=Cur_Heap->Stored_Edge[Cur_Heap->Heap_Length-1].Second_Vtx;
  Cur_Heap->Stored_Edge[0].Cost=Cur_Heap->Stored_Edge[Cur_Heap->Heap_Length-1].Cost;
  Cur_Heap->Heap_Length--;
  
  Binary_Heap_Move_Down(Cur_Heap,0);
  return Min_Edge_Index;     
}//End Binary_Heap_Extract_Min_Edge()

//Print elements information of a binary heap
void Binary_Heap_Print_Elements(Binary_Heap *Cur_Heap)
{
  printf("Binary heap length:%d\n",Cur_Heap->Heap_Length);
  for(int i=0;i<Cur_Heap->Heap_Length;i++)
    printf("%d  %d->%d: %d\n",i+1,Cur_Heap->Stored_Edge[i].First_Vtx,
      Cur_Heap->Stored_Edge[i].Second_Vtx,Cur_Heap->Stored_Edge[i].Cost);     
}//End Binary_Heap_Print_Elements()

/*******************************************************************************
**The following functions are used for leftiest heap operations
*******************************************************************************/

#define Null_Node  NULL
//Data structure used for leftiest heap
struct LHeap_Node{
  int Edge_First_Vtx;
  int Edge_Second_Vtx;
  Cost_Type Edge_Cost; 
    
  int NPL;
  LHeap_Node *Left_Child;
  LHeap_Node *Right_Child;
};

//Get the edge cost of the root node of leftiest heap
Cost_Type LHeap_Get_Root_Cost(LHeap_Node* Cur_Heap)
{
  if(Cur_Heap!=Null_Node) 
    return Cur_Heap->Edge_Cost;
  else
  {
    printf("LHeap_Get_Root_Cost() fail! The curent heap is null!\n");
    getchar();
    return Null;
  }
}//End LHeap_Get_Root_Cost()

//Get the first vtx of the root node of leftiest heap
int LHeap_Get_Root_First_Vtx(LHeap_Node* Cur_Heap)
{
  if(Cur_Heap!=Null_Node) 
    return Cur_Heap->Edge_First_Vtx;
  else
  {
    printf("LHeap_Get_Root_First_Vtx() fail! The curent heap is null!\n");
    getchar();
    return Null;
  }
}//End LHeap_Get_Root_First_Vtx() 

//Get the second vtx of the root node of leftiest heap
int LHeap_Get_Root_Second_Vtx(LHeap_Node* Cur_Heap)
{
  if(Cur_Heap!=Null_Node) 
    return Cur_Heap->Edge_Second_Vtx;
  else
  {
    printf("LHeap_Get_Root_Second_Vtx() fail! The curent heap is null!\n");
    getchar();
    return Null;
  }
}//End LHeap_Get_Root_Second_Vtx() 

//Get the NPL information of a given LHeap node
int Get_LHeap_Node_NPL(LHeap_Node* Cur_LHeap_Node)
{
  if(Cur_LHeap_Node!=Null_Node)
    return Cur_LHeap_Node->NPL;
  else
  {
    printf("Get_LHeap_Node_NPL() fail! The curent heap node is null!\n");
    getchar();
    return Null;
  }
}//End Get_LHeap_Node_NPL() 

//Swap the left and right children of a given LHeap node
void LHeap_Swap_Children(LHeap_Node* Cur_LHeap_Node) 
{
  if(Cur_LHeap_Node!=Null_Node)
  {
    LHeap_Node* Tmp_Heap=Cur_LHeap_Node->Left_Child;
    Cur_LHeap_Node->Left_Child=Cur_LHeap_Node->Right_Child;
    Cur_LHeap_Node->Right_Child=Tmp_Heap;
  }
  else
  {
    printf("LHeap_Swap_Children() fail! The curent heap node is null!\n");
    getchar();    
  }
}//End LHeap_Swap_Children() 

LHeap_Node* LHeap_Exact_Merge(LHeap_Node* First_Heap, LHeap_Node* Second_Heap);

//Merge two LHeap nodes and return the root
LHeap_Node* LHeap_Merge(LHeap_Node* First_Heap,LHeap_Node* Second_Heap) 
{
  //If one heap is null, return the other
  if(First_Heap==Null_Node) 
    return Second_Heap;
  if(Second_Heap==Null_Node) 
    return First_Heap;

  //If both are not null
  if(First_Heap->Edge_Cost < Second_Heap->Edge_Cost) 
    return LHeap_Exact_Merge(First_Heap,Second_Heap);
  else
    return LHeap_Exact_Merge(Second_Heap,First_Heap);
}//End LHeap_Merge()

//Exactly merge two heaps (with First_Heap being the root) while meeting the leftiest heap definition 
LHeap_Node* LHeap_Exact_Merge(LHeap_Node* First_Heap,LHeap_Node* Second_Heap)
{
  if(First_Heap->Left_Child==Null_Node) 
    First_Heap->Left_Child=Second_Heap; 
  else 
  {
    First_Heap->Right_Child=LHeap_Merge(First_Heap->Right_Child,Second_Heap);
    if(Get_LHeap_Node_NPL(First_Heap->Left_Child)<Get_LHeap_Node_NPL(First_Heap->Right_Child))
      LHeap_Swap_Children(First_Heap);
 
    First_Heap->NPL=Get_LHeap_Node_NPL(First_Heap->Right_Child)+1; //Update NPL
  }
  return First_Heap;
}//End LHeap_Exact_Merge() 

//Insert a new node to leftiest heap
LHeap_Node* LHeap_Insert(LHeap_Node* Cur_Heap,int First_Vtx,int Second_Vtx,Cost_Type Cost)
{
  LHeap_Node* New_Heap_Node;  
  New_Heap_Node = new LHeap_Node;

  New_Heap_Node->Edge_First_Vtx=First_Vtx;
  New_Heap_Node->Edge_Second_Vtx=Second_Vtx;
  New_Heap_Node->Edge_Cost=Cost;
  New_Heap_Node->NPL=0;
  New_Heap_Node->Left_Child=Null_Node;
  New_Heap_Node->Right_Child=Null_Node;
   
  return LHeap_Merge(Cur_Heap,New_Heap_Node);
}//End LHeap_Insert() 

//Delete the root node of a leftiest heap and release the memory
LHeap_Node* LHeap_Delete_Root(LHeap_Node* Cur_Heap)
{ 
  LHeap_Node* Left_Heap=Cur_Heap->Left_Child; 
  LHeap_Node* Right_Heap=Cur_Heap->Right_Child;  
  
  delete Cur_Heap;   
  Cur_Heap=Null_Node;
  
  return LHeap_Merge(Left_Heap,Right_Heap);  
}//End LHeap_Delete_Root()

//Delete a leftiest heap and release the memory
void Delete_Heap(LHeap_Node *Cur_Heap)
{
  while(Cur_Heap!=Null_Node)
    Cur_Heap=LHeap_Delete_Root(Cur_Heap);      
}//End Delete_Heap() 
