/*******************************************************************************
****The following functions are used to dynamiclly delete a vertex
*******************************************************************************/
Cost_Type *Delete_Vtx_Reduced_Cost;
LHeap_Node **Vertical_Edges_LHeap;
int **Horizontal_Edge_List;
Struct_Edge *Candidate_Edge;

int *Delete_Changed_Vtx;
int Delete_Changed_Vtx_Num;
int *Union_Find_Set_Bak;

Profit_Type *Delete_Vtx_Increased_Profit;

//Initialize the leftiest heaps of each vtx containing all the vertical edges
void Add_All_Vertical_Edge_To_LHeap(Struct_Solution *Cur_Solution)
{  
  for(int i=0;i<Vtx_Num;i++)
  {
    if(Vertical_Edges_LHeap[i]!=Null_Node)
      Delete_Heap(Vertical_Edges_LHeap[i]); 
          
    Vertical_Edges_LHeap[i]=Null_Node;    
  }

  for(int i=0;i<Selected_Edge_Num;i++) 
  {
    int First_Vtx=Selected_Edge[i].First_Vtx;
    int Second_Vtx=Selected_Edge[i].Second_Vtx;   
    if(!Cur_Solution->If_Vtx_Spanned[First_Vtx] || !Cur_Solution->If_Vtx_Spanned[Second_Vtx])
      continue;
         
    int Shared_Root=Get_Shared_Root(Cur_Solution,First_Vtx,Second_Vtx);    
    if(Shared_Root==Null)
      continue;
      
    if(Shared_Root!=First_Vtx && Shared_Root!=Cur_Solution->Vtx_Parent[First_Vtx])
    {
      Vertical_Edges_LHeap[First_Vtx]=LHeap_Insert(Vertical_Edges_LHeap[First_Vtx],First_Vtx,Second_Vtx,Selected_Edge[i].Cost);
      //printf("Add vertical edge (%d %d) to heap %d\n",First_Vtx,Second_Vtx,First_Vtx);      
    }
    
    if(Shared_Root!=Second_Vtx && Shared_Root!=Cur_Solution->Vtx_Parent[Second_Vtx])
    {
      Vertical_Edges_LHeap[Second_Vtx]=LHeap_Insert(Vertical_Edges_LHeap[Second_Vtx],Second_Vtx,First_Vtx,Selected_Edge[i].Cost);
      //printf("Add vertical edge (%d %d) to heap %d\n",First_Vtx,Second_Vtx,Second_Vtx);      
    }      
  }//End for  
}//End Add_All_Vertical_Edges_To_LHeap()


int Max_Horizontal_Edge_Num;
int *Horizontal_Edge_Num;
int Get_Max_Horizontal_Edge_Num(Struct_Solution *Cur_Solution)
{    
  for(int i=0;i<Vtx_Num;i++)
    Horizontal_Edge_Num[i]=0;

  for(int i=0;i<Selected_Edge_Num;i++) 
  {
    int First_Vtx=Selected_Edge[i].First_Vtx;
    int Second_Vtx=Selected_Edge[i].Second_Vtx;
    if(!Cur_Solution->If_Vtx_Spanned[First_Vtx] || !Cur_Solution->If_Vtx_Spanned[Second_Vtx])
      continue;          
     
    int Shared_Root=Get_Shared_Root(Cur_Solution,First_Vtx,Second_Vtx);      
    if(Shared_Root==Null)
      continue;
      
    if(Shared_Root!=First_Vtx && Shared_Root!=Second_Vtx)
      Horizontal_Edge_Num[Shared_Root]++;
  
  }//End for 
  
  int Max_Edge_Num=0;
  for(int i=0;i<Vtx_Num;i++)
    if(Horizontal_Edge_Num[i]>Max_Edge_Num)
      Max_Edge_Num=Horizontal_Edge_Num[i];
  
  return Max_Edge_Num;    
}

bool Reallocate_Memory(Struct_Solution *Cur_Solution)
{
  int Max_Edge_Num=Get_Max_Horizontal_Edge_Num(Cur_Solution);
  if(Max_Horizontal_Edge_Num < Max_Edge_Num)
  {
    Max_Horizontal_Edge_Num=Max_Edge_Num;  
    
    for(int i=0;i<Vtx_Num;i++)
      delete []Horizontal_Edge_List[i];
    delete []Horizontal_Edge_List;
    
    Horizontal_Edge_List=new int *[Vtx_Num];  
    for(int i=0;i<Vtx_Num;i++)
      Horizontal_Edge_List[i]=new int [Max_Horizontal_Edge_Num];    
    
    return true;                                                     
  }     
  
  return false;
}

//Add the index of each horizontal edge to the corresponding list
void Add_All_Horizontal_Edge_To_List(Struct_Solution *Cur_Solution)
{
  Reallocate_Memory(Cur_Solution);
     
  //The number of horizontal edges of each vtx   
  for(int i=0;i<Vtx_Num;i++)
    Horizontal_Edge_List[i][0]=0;

  for(int i=0;i<Selected_Edge_Num;i++) 
  {
    int First_Vtx=Selected_Edge[i].First_Vtx;
    int Second_Vtx=Selected_Edge[i].Second_Vtx;
    if(!Cur_Solution->If_Vtx_Spanned[First_Vtx] || !Cur_Solution->If_Vtx_Spanned[Second_Vtx])
      continue;          
     
    int Shared_Root=Get_Shared_Root(Cur_Solution,First_Vtx,Second_Vtx);      
    if(Shared_Root==Null)
      continue;
      
    if(Shared_Root!=First_Vtx && Shared_Root!=Second_Vtx)
    {
      Horizontal_Edge_List[Shared_Root][0]++;
      Horizontal_Edge_List[Shared_Root][Horizontal_Edge_List[Shared_Root][0]]=i;
      //printf("Add horizontal edge (%d %d) to heap %d\n",First_Vtx,Second_Vtx,Shared_Root);      
    }
  }//End for 
}//End Add_All_Horizontal_Edge_To_List()

//Record a vertx whose status has been changed during deletion
void Record_Delete_Changed_Vtx(int Changed_Vtx_index)
{
  if(Delete_Changed_Vtx_Num<Vtx_Num)
    Delete_Changed_Vtx[Delete_Changed_Vtx_Num++]=Changed_Vtx_index;    
}//End Record_Delete_Changed_Vtx()

//Remove a vtx and the incident edges
int Remove_Vtx(Struct_Solution *Cur_Solution,int Union_Find_Set[],int Vtx_Index)
{
  if(!Cur_Solution->If_Vtx_Spanned[Vtx_Index])
  {
    printf("Remove_Vtx() fail! Vtx %d is not spanned!\n",Vtx_Index);     
    if(If_Stop_At_Error)
      getchar();
    return Null;                                       
  }
  
  Delete_Changed_Vtx_Num=0;    
  int Removed_Edge_Num=0;
   
  Cur_Solution->If_Vtx_Spanned[Vtx_Index]=false; 
  Union_Find_Set[Vtx_Index]=Vtx_Index;  
  Cur_Solution->Collected_Profit-=Vtx_Profit[Vtx_Index]; 
  if(Cur_Solution->Vtx_Parent[Vtx_Index]!=Null) 
  {                  
    Cur_Solution->Solution_Cost-=Edge_Cost[Vtx_Index][Cur_Solution->Vtx_Parent[Vtx_Index]];
    Cur_Solution->Vtx_Parent[Vtx_Index]=Null;
    Union_Find_Set[Vtx_Index]=Vtx_Index;
    Record_Delete_Changed_Vtx(Vtx_Index);   
    Removed_Edge_Num++; 
  }        
  
  for(int i=0;i<Vtx_Child_Num[Vtx_Index];i++)
  {
    int Child_Vtx=Vtx_Children[Vtx_Index][i];    
    if(Cur_Solution->Vtx_Parent[Child_Vtx]!=Null) 
    {                  
      Cur_Solution->Solution_Cost-=Edge_Cost[Child_Vtx][Cur_Solution->Vtx_Parent[Child_Vtx]];
      Cur_Solution->Vtx_Parent[Child_Vtx]=Null;  
      Union_Find_Set[Child_Vtx]=Child_Vtx;
      Record_Delete_Changed_Vtx(Child_Vtx);       
      Removed_Edge_Num++;  
    }
  }
  
  return Removed_Edge_Num;
}//End Remove_Vtx()

//Clean up Leftiest heap until the top edge is a valid vertical edge
LHeap_Node *Cleanup_Leftiest_Heap(LHeap_Node *Cur_Heap,Struct_Solution *Cur_Solution,int Root,int Cur_Vtx)
{
  LHeap_Node *Temp_Heap=Cur_Heap;
  while(Temp_Heap!=Null_Node)
  {
    int First_Vtx=LHeap_Get_Root_First_Vtx(Temp_Heap);
    int Second_Vtx=LHeap_Get_Root_Second_Vtx(Temp_Heap);
    int First_Ancestor=Get_Vtx_Ancestor(Cur_Solution,First_Vtx);
    int Second_Ancestor=Get_Vtx_Ancestor(Cur_Solution,Second_Vtx);   
    if(First_Ancestor==Root && Second_Ancestor==Cur_Vtx)    
      break;
    if(First_Ancestor==Cur_Vtx && Second_Ancestor==Root)    
      break;  

    Temp_Heap=LHeap_Delete_Root(Temp_Heap);
  }
  
  return Temp_Heap;
}//End Cleanup_Leftiest_Heap()

//Merge the children leftiest heaps to the parent heap 
void Merge_Sub_LHeap(int Vtx_Index)
{
  for(int i=0;i<Vtx_Child_Num[Vtx_Index];i++)
  {
    int Child_Vtx=Vtx_Children[Vtx_Index][i];
    Vertical_Edges_LHeap[Vtx_Index]=LHeap_Merge(Vertical_Edges_LHeap[Vtx_Index],Vertical_Edges_LHeap[Child_Vtx]);
    Vertical_Edges_LHeap[Child_Vtx]=Null_Node;    
  }
}//End Merge_Sub_LHeap(Struct_Solution *Cur_Solution,int Vtx_Index)

//Get all the candidate edges for reconstructing the MST after deleting a given vtx 
int Get_Candidate_Edge(Struct_Solution *Cur_Solution,int Vtx_Index)
{
  int Candidate_Edge_Num=0;
  //Get the horizontal candidate edges
  for(int i=1;i<=Horizontal_Edge_List[Vtx_Index][0];i++)
  {
    int Edge_Index=Horizontal_Edge_List[Vtx_Index][i];
    Candidate_Edge[Candidate_Edge_Num].First_Vtx=Selected_Edge[Edge_Index].First_Vtx;
    Candidate_Edge[Candidate_Edge_Num].Second_Vtx=Selected_Edge[Edge_Index].Second_Vtx;
    Candidate_Edge[Candidate_Edge_Num].Cost=Selected_Edge[Edge_Index].Cost;  
    Candidate_Edge_Num++; 
  } 
  //Get the candidate vertical edges
  for(int i=0;i<Vtx_Child_Num[Vtx_Index];i++)
  {
    int Child_Vtx=Vtx_Children[Vtx_Index][i];    
    Vertical_Edges_LHeap[Child_Vtx]=Cleanup_Leftiest_Heap(Vertical_Edges_LHeap[Child_Vtx],Cur_Solution,Cur_Solution->Root,Child_Vtx);    
    if(Vertical_Edges_LHeap[Child_Vtx]!=Null_Node)
    {          
      Candidate_Edge[Candidate_Edge_Num].First_Vtx=LHeap_Get_Root_First_Vtx(Vertical_Edges_LHeap[Child_Vtx]);        
      Candidate_Edge[Candidate_Edge_Num].Second_Vtx=LHeap_Get_Root_Second_Vtx(Vertical_Edges_LHeap[Child_Vtx]);        
      Candidate_Edge[Candidate_Edge_Num].Cost=LHeap_Get_Root_Cost(Vertical_Edges_LHeap[Child_Vtx]);       
      Candidate_Edge_Num++; 
      //Vertical_Edges_LHeap[Vtx_Index]=LHeap_Merge(Vertical_Edges_LHeap[Vtx_Index],Vertical_Edges_LHeap[Child_Vtx]);  
      //Vertical_Edges_LHeap[Child_Vtx]=Null_Node;    
    }       
  }

  Merge_Inc_Sort_Edge(Candidate_Edge,Candidate_Edge_Num); 
  return Candidate_Edge_Num;
}//End Get_Candidate_Edge(Struct_Solution *Cur_Solution,int Vtx_Index)

//Reconstruct a solution after deleting a vtx, using the candidate edges
bool Kruskal_Repair_MST(Struct_Solution *Cur_Solution,int Union_Find_Set[], 
                 Struct_Edge Candidate_Edge[],int Candidate_Edge_Num,int Edge_Num_To_Add)
{   
  int Added_Edge_Num=0;  
  for(int i=0;i<Candidate_Edge_Num;i++)
  { 
    if(Added_Edge_Num>=Edge_Num_To_Add)
      break;   
      
    int First_Vtx=Candidate_Edge[i].First_Vtx;
    int Second_Vtx=Candidate_Edge[i].Second_Vtx;    
    if(!Cur_Solution->If_Vtx_Spanned[First_Vtx] || !Cur_Solution->If_Vtx_Spanned[Second_Vtx] 
      || Edge_Cost[First_Vtx][Second_Vtx]>=Inf_Cost
      || Get_Union_Find_Index(Union_Find_Set,First_Vtx)==Get_Union_Find_Index(Union_Find_Set,Second_Vtx)) 
      continue; 

    Cur_Solution->Solution_Cost+=Edge_Cost[First_Vtx][Second_Vtx];
    int First_Union_Find_Index=Get_Union_Find_Index(Union_Find_Set,First_Vtx);
    int Second_Union_Find_Index=Get_Union_Find_Index(Union_Find_Set,Second_Vtx);
    if(Second_Union_Find_Index==Cur_Solution->Root)
    {
      Union_Find_Set[First_Union_Find_Index]=Second_Union_Find_Index;
      Record_Delete_Changed_Vtx(First_Union_Find_Index); 
    }
    else
    {
      Union_Find_Set[Second_Union_Find_Index]=First_Union_Find_Index;  
      Record_Delete_Changed_Vtx(Second_Union_Find_Index); 
    }
    Added_Edge_Num++;
  }  
  
  if(Added_Edge_Num>=Edge_Num_To_Add) 
    Cur_Solution->If_Feasible=true;
  else
    Cur_Solution->If_Feasible=false;
       
  return Cur_Solution->If_Feasible;
}//End Kruskal_Repair_MST()

//Get the reduced cost corresponding to deleting each vtx (using a dynamic and efficient method)
void Get_All_Delete_Vtx_Reduced_Cost(Struct_Solution *Cur_Solution)
{         
  Cost_Type Pre_Obj=Get_Solution_Obj(Cur_Solution);
  Copy_Solution(&Temp_Solution,Cur_Solution,1); 

  Add_All_Vertical_Edge_To_LHeap(Cur_Solution);
  Add_All_Horizontal_Edge_To_List(Cur_Solution);  

  Update_Union_Find_Set(Union_Find_Set,Cur_Solution);
  Copy_Union_Find_Set(Union_Find_Set_Bak,Union_Find_Set);    
    
  for(int i=0;i<Vtx_Num;i++)
    Delete_Vtx_Reduced_Cost[i]=-Inf_Cost;  
  
  Spanned_Vtx_Num=Post_Order_Traverse_Solution(Cur_Solution);      
  for(int i=0;i<Spanned_Vtx_Num;i++)
  {         
    int Cur_Vtx=Post_Order_Vtx[i];       
    int Removed_Edge_Num=Remove_Vtx(Cur_Solution,Union_Find_Set,Cur_Vtx);      
    int Candidate_Edge_Num=Get_Candidate_Edge(Cur_Solution,Cur_Vtx);  
    Merge_Sub_LHeap(Cur_Vtx);   
     
    if(Kruskal_Repair_MST(Cur_Solution,Union_Find_Set,Candidate_Edge,Candidate_Edge_Num,Removed_Edge_Num-1))      
      Delete_Vtx_Reduced_Cost[Cur_Vtx]=Pre_Obj-Get_Solution_Obj(Cur_Solution);
    else
      Delete_Vtx_Reduced_Cost[Cur_Vtx]=-Inf_Cost;     
      
    if(Delete_Changed_Vtx_Num<Vtx_Num)      
    {
      Part_Restore_Solution(Cur_Solution,&Temp_Solution,Delete_Changed_Vtx,Delete_Changed_Vtx_Num);      
      Part_Restore_Union_Find_Set(Union_Find_Set,Union_Find_Set_Bak,Delete_Changed_Vtx,Delete_Changed_Vtx_Num); 
    }       
    else
    {
      Copy_Solution(Cur_Solution,&Temp_Solution,1);
      Copy_Union_Find_Set(Union_Find_Set,Union_Find_Set_Bak);
    }    
  }//End for 

  Copy_Solution(Cur_Solution,&Temp_Solution,1);
}//End Get_All_Delete_Vtx_Reduced_Cost()

void Get_All_Delete_Vtx_Increased_Profit(Struct_Solution *Cur_Solution)
{
  Get_All_Delete_Vtx_Reduced_Cost(Cur_Solution);     
  for(int i=0;i<Vtx_Num;i++)
  {
    if(Delete_Vtx_Reduced_Cost[i]!=-Inf_Cost)
      Delete_Vtx_Increased_Profit[i]=-Vtx_Profit[i];   
    else
      Delete_Vtx_Increased_Profit[i]=-Inf_Cost; 
  }
}

//Initialiaze the data structure used to delete vtx 
void Delete_Vertex_Init()
{       
  Vertical_Edges_LHeap=new LHeap_Node *[Vtx_Num];
  for(int i=0;i<Vtx_Num;i++)
    Vertical_Edges_LHeap[i]=Null_Node;  
    
  Horizontal_Edge_Num=new int [Vtx_Num]; 
  
  Max_Horizontal_Edge_Num=Vtx_Num;
  Horizontal_Edge_List=new int *[Vtx_Num];  
  for(int i=0;i<Vtx_Num;i++)
    Horizontal_Edge_List[i]=new int [Max_Horizontal_Edge_Num];
        
  Candidate_Edge=new Struct_Edge[Edge_Num];     
  Delete_Vtx_Reduced_Cost=new Cost_Type [Vtx_Num]; 
  Delete_Changed_Vtx=new int [Vtx_Num]; 
  Union_Find_Set_Bak=new int [Vtx_Num]; 
  
  //Added code
  Delete_Vtx_Increased_Profit=new Profit_Type [Vtx_Num];  
}//End Delete_Vertex_Init

//Release the memory used to delete vtx
void Delete_Vertex_Release_Memory()
{
  for(int i=0;i<Vtx_Num;i++) 
    Delete_Heap(Vertical_Edges_LHeap[i]); 
  delete []Vertical_Edges_LHeap;  

  delete []Horizontal_Edge_Num;
  for(int i=0;i<Vtx_Num;i++)
    delete []Horizontal_Edge_List[i];
  delete []Horizontal_Edge_List;
  
  delete []Candidate_Edge;  
  delete []Delete_Vtx_Reduced_Cost;
  delete []Delete_Changed_Vtx;  
  delete []Union_Find_Set_Bak; 
  
  //Added code
  delete []Delete_Vtx_Increased_Profit;
}//End Delete_Vertex_Release_Memory()
