
//Verify if connect a customer would lead to an improved solution
bool Verify_If_Improved_Customer(Struct_Solution *Cur_Solution,int Vtx_To_Connect)
{
  Copy_Solution(&Temp_Solution,Cur_Solution); 
   
  Profit_Type Pre_Obj=Get_Solution_Obj(Cur_Solution); 
   
  bool If_Success=Connect_New_Vtx(Cur_Solution,Vtx_To_Connect);
  Kruskal_MST(Cur_Solution); 
  
  Profit_Type After_Obj=Get_Solution_Obj(Cur_Solution);
  
  Copy_Solution(Cur_Solution,&Temp_Solution); 
  
  if(If_Success && After_Obj>=Pre_Obj) 
    return true;
  else
    return false;     
}

//Randomly get the index of an unconnected customer which could improve the objective value
int MWCS_Randomly_Get_Customer(Struct_Solution *Cur_Solution)
{
  int Begin_Index=Get_Random_Int(Vtx_Num); 
  for(int i=0;i<Vtx_Num;i++)
  {
    int Cur_Vtx=(Begin_Index+i)%Vtx_Num; 
    if(Cur_Solution->If_Vtx_Spanned[Cur_Vtx] || Vtx_Profit[Cur_Vtx]<=0)
      continue;     
    
    if(Get_Cost_To_Connect_Vtx(Cur_Solution,Cur_Vtx) >= Inf_Cost)
      continue;   
      
    if(Verify_If_Improved_Customer(Cur_Solution,Cur_Vtx))
      return Cur_Vtx;
  }    

  return Null;
}

bool Construct_Initial_Solution(Struct_Solution *Cur_Solution)
{
  for(int i=0;i<Vtx_Num;i++)
    Cur_Solution->If_Vtx_Spanned[i]=false; 
    
  int Begin_Index=Get_Random_Int(Vtx_Num);     
  for(int i=0;i<Vtx_Num;i++)
  {
    int Cur_Vtx=(Begin_Index+i)%Vtx_Num;
    if(Vtx_Profit[Cur_Vtx]>0)
    {
      Cur_Solution->If_Vtx_Spanned[Cur_Vtx]=true;
        break; 
    }  
  }
  
  Kruskal_MST(Cur_Solution); 
  
  while(true)
  {
    int Vtx_To_Connect=MWCS_Randomly_Get_Customer(Cur_Solution);
    if(Vtx_To_Connect==Null)
      break;  
    
    if(Connect_New_Vtx(Cur_Solution,Vtx_To_Connect))  
      Kruskal_MST(Cur_Solution); 
    else
      break;      
  }
  
  return Cur_Solution->If_Feasible;        
}



