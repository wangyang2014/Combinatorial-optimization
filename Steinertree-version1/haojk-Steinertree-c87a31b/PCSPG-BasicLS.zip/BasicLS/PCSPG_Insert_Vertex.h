/*******************************************************************************
****The following functions are used to dynamiclly insert a vertex
*******************************************************************************/

Cost_Type *Insert_Vtx_Reduced_Cost;
int *Insert_Changed_Vtx;
int Insert_Changed_Vtx_Num;

//Get the child vtx of the worst edge on the loop
int Get_Worst_Vtx_On_Loop(Struct_Solution *Cur_Solution,int First_Vtx,int Second_Vtx)
{
  Cost_Type Worst_Loop_Cost=0;
  int Worst_Vtx=First_Vtx;
  
  int Shared_Root=Get_Shared_Root(Cur_Solution,First_Vtx,Second_Vtx);
  if(Shared_Root==Null)
    return Null;
  
  int Temp_First_Vtx=First_Vtx;
  while(Temp_First_Vtx!=Shared_Root)
  {
    int Parent=Cur_Solution->Vtx_Parent[Temp_First_Vtx];
    if(Edge_Cost[Temp_First_Vtx][Parent]>Worst_Loop_Cost) 
    {
      Worst_Loop_Cost=Edge_Cost[Temp_First_Vtx][Parent];
      Worst_Vtx=Temp_First_Vtx;
    }
    Temp_First_Vtx=Parent;                                
  }
  
  int Temp_Second_Vtx=Second_Vtx;
  while(Temp_Second_Vtx!=Shared_Root)
  {
    int Parent=Cur_Solution->Vtx_Parent[Temp_Second_Vtx];
    if(Edge_Cost[Temp_Second_Vtx][Parent]>Worst_Loop_Cost) 
    {
      Worst_Loop_Cost=Edge_Cost[Temp_Second_Vtx][Parent];
      Worst_Vtx=Temp_Second_Vtx;
    }
    Temp_Second_Vtx=Parent;                                
  }
  
  return Worst_Vtx;           
}//End Get_Worst_Vtx_On_Loop()

//Record a vertx whose status has been changed during insertion
void Record_Insert_Changed_Vtx(int Changed_Vtx_index)
{
  if(Insert_Changed_Vtx_Num<Vtx_Num)
    Insert_Changed_Vtx[Insert_Changed_Vtx_Num++]=Changed_Vtx_index;    
}//End Record_Insert_Changed_Vtx

//Swap two edges
void Swap_Edge(Struct_Solution *Cur_Solution,int Deleted_Edge_First_Vtx, 
               int Deleted_Edge_Second_Vtx,int Added_Edge_First_Vtx,int Added_Edge_Second_Vtx)
{ 
  Record_Insert_Changed_Vtx(Deleted_Edge_First_Vtx);
  Record_Insert_Changed_Vtx(Deleted_Edge_Second_Vtx);
  Record_Insert_Changed_Vtx(Added_Edge_First_Vtx);
  Record_Insert_Changed_Vtx(Added_Edge_Second_Vtx);
  
  if(Cur_Solution->Vtx_Parent[Deleted_Edge_Second_Vtx]==Deleted_Edge_First_Vtx) 
    Cur_Solution->Vtx_Parent[Deleted_Edge_Second_Vtx]=Null;      
  else 
    Cur_Solution->Vtx_Parent[Deleted_Edge_First_Vtx]=Null;     
   
  int Added_Vtx_In_Main_Tree,Added_Vtx_In_Sub_Tree;
  if(Get_Vtx_Ancestor(Cur_Solution,Added_Edge_First_Vtx)==Cur_Solution->Root)
  {
    Added_Vtx_In_Main_Tree=Added_Edge_First_Vtx;
    Added_Vtx_In_Sub_Tree=Added_Edge_Second_Vtx;                                    
  }
  else 
  {
    Added_Vtx_In_Main_Tree=Added_Edge_Second_Vtx;
    Added_Vtx_In_Sub_Tree=Added_Edge_First_Vtx;                 
  }
   
  int Current_Vtx=Added_Vtx_In_Sub_Tree;
  int Parent_Vtx=Cur_Solution->Vtx_Parent[Current_Vtx];   
  Cur_Solution->Vtx_Parent[Added_Vtx_In_Sub_Tree]=Added_Vtx_In_Main_Tree;  
  while(Parent_Vtx!=Null)
  {       
    Record_Insert_Changed_Vtx(Parent_Vtx);                        
    int Temp_Vtx=Cur_Solution->Vtx_Parent[Parent_Vtx];
    Cur_Solution->Vtx_Parent[Parent_Vtx]=Current_Vtx;
    Current_Vtx=Parent_Vtx;
    Parent_Vtx=Temp_Vtx;                   
  }    

  Cur_Solution->Solution_Cost+=Edge_Cost[Added_Edge_First_Vtx][Added_Edge_Second_Vtx];
  Cur_Solution->Solution_Cost-=Edge_Cost[Deleted_Edge_First_Vtx][Deleted_Edge_Second_Vtx];
}//End Swap_Edge(Struct_Solution *Cur_Solution, int, int, int, int)

//Use edge (First_Vtx,Second_Vtx) to replace the worst edge on the loop
bool Replace_Worst_Edge(Struct_Solution *Cur_Solution,int First_Vtx,int Second_Vtx)
{
  if(!Cur_Solution->If_Vtx_Spanned[First_Vtx] || !Cur_Solution->If_Vtx_Spanned[Second_Vtx])
    return false;
    
  int Worst_Vtx=Get_Worst_Vtx_On_Loop(Cur_Solution,First_Vtx,Second_Vtx);
  int Worst_Parent=Cur_Solution->Vtx_Parent[Worst_Vtx];  
  if(Edge_Cost[First_Vtx][Second_Vtx]<Edge_Cost[Worst_Vtx][Worst_Parent]) 
    Swap_Edge(Cur_Solution,Worst_Vtx,Worst_Parent,First_Vtx,Second_Vtx);
  
  return true;  
}//End Replace_Worst_Edge(Struct_Solution *Cur_Solution, int First_Vtx, int Second_Vtx);

//Insert a new vtx to the current solution 
bool Insert_New_Edge(Struct_Solution *Cur_Solution,int Origin_Vtx,int New_Vtx)
{
  if(!Cur_Solution->If_Vtx_Spanned[Origin_Vtx] || Cur_Solution->If_Vtx_Spanned[New_Vtx]) 
    return false;
  if(Edge_Cost[Origin_Vtx][New_Vtx]>=Inf_Cost)
    return false;
  
  Cur_Solution->Vtx_Parent[New_Vtx]=Origin_Vtx; 
  Cur_Solution->If_Vtx_Spanned[New_Vtx]=true;
  Cur_Solution->Solution_Cost+=Edge_Cost[New_Vtx][Origin_Vtx];
  Cur_Solution->Collected_Profit+=Vtx_Profit[New_Vtx];
  Record_Insert_Changed_Vtx(New_Vtx);
  return true;      
}//End Insert_New_Edge()

//Partially restore the current solution (only the changed vtx are restored) 
void Part_Restore_Solution(Struct_Solution *Dest_Solution,Struct_Solution *Orign_Solution,int Insert_Changed_Vtx[],int Insert_Changed_Vtx_Num)
{
  for(int i=0;i<Insert_Changed_Vtx_Num;i++)
  {
    int Vtx_To_Restore=Insert_Changed_Vtx[i];
    Dest_Solution->If_Vtx_Spanned[Vtx_To_Restore]=Orign_Solution->If_Vtx_Spanned[Vtx_To_Restore];
    Dest_Solution->Vtx_Parent[Vtx_To_Restore]=Orign_Solution->Vtx_Parent[Vtx_To_Restore]; 
  } 
  
  Dest_Solution->Root=Orign_Solution->Root;
  Dest_Solution->Solution_Cost=Orign_Solution->Solution_Cost;
  Dest_Solution->Collected_Profit=Orign_Solution->Collected_Profit;
  Dest_Solution->If_Feasible=Orign_Solution->If_Feasible; 
}//End Part_Restore_Solution()

//Insert a new vtx to the solution, return the reduced cost
Cost_Type Get_Insert_Vtx_Reduced_Cost(Struct_Solution *Cur_Solution,Struct_Solution *Bak_Solution,int Vtx_To_Insert)
{ 
  if(Cur_Solution->If_Vtx_Spanned[Vtx_To_Insert])  
    return -Inf_Cost;
 
  Cost_Type Pre_Obj=Get_Solution_Obj(Cur_Solution);
  Insert_Changed_Vtx_Num=0;
  bool If_Feasible=false;
  for(int i=0;i<Vtx_Degree[Vtx_To_Insert];i++)
  {
    int Vtx_To_Connect=Adjacent_Vtx[Vtx_To_Insert][i];
    if(!Cur_Solution->If_Vtx_Spanned[Vtx_To_Connect]) 
      continue;
    if(!Cur_Solution->If_Vtx_Spanned[Vtx_To_Insert])
    {
      if(Insert_New_Edge(Cur_Solution,Vtx_To_Connect,Vtx_To_Insert))
        If_Feasible=true;     
    }
    else
    {
      if(Replace_Worst_Edge(Cur_Solution,Vtx_To_Connect,Vtx_To_Insert))
        If_Feasible=true;
    }
  }
  Cost_Type After_Obj=Get_Solution_Obj(Cur_Solution);   
  
  if(Insert_Changed_Vtx_Num<Vtx_Num)  
    Part_Restore_Solution(Cur_Solution,Bak_Solution,Insert_Changed_Vtx,Insert_Changed_Vtx_Num); 
  else
    Copy_Solution(Cur_Solution,Bak_Solution,1);
  
  if(If_Feasible)
    return Pre_Obj-After_Obj; 
  else    
    return -Inf_Cost;
}//End Get_Insert_Vtx_Reduced_Cost()

//Get the reduced cost corresponding to inserting each vtx (using a dynamic and efficient method)
void Get_All_Insert_Vtx_Reduced_Cost(Struct_Solution *Cur_Solution)
{
  Copy_Solution(&Temp_Solution,Cur_Solution,1);
  int Spanned_Vtx_Num=0;
  for(int i=0;i<Vtx_Num;i++)
    if(Cur_Solution->If_Vtx_Spanned[i])
      Spanned_Vtx_Num++;

  for(int i=0;i<Vtx_Num;i++) 
  {
    if(Spanned_Vtx_Num>0)
      Insert_Vtx_Reduced_Cost[i]=Get_Insert_Vtx_Reduced_Cost(Cur_Solution,&Temp_Solution,i);
    else
      Insert_Vtx_Reduced_Cost[i]=Vtx_Profit[i];
  }
  
  Copy_Solution(Cur_Solution,&Temp_Solution,1);
}//End Get_All_Insert_Vtx_Reduced_Cost(Struct_Solution *Cur_Solution)

//Initialiaze the data structure used to insert Steiner vtx
void Insert_Vertex_Init()
{  
  Insert_Vtx_Reduced_Cost=new Cost_Type[Vtx_Num];
  Insert_Changed_Vtx=new int[Vtx_Num];
  Insert_Changed_Vtx_Num=0;
}//End Insert_Vertex_Init()

//Release the memory used to insert Steiner vtx
void Insert_Vertex_Release_Memory()
{  
  delete []Insert_Vtx_Reduced_Cost;   
  delete []Insert_Changed_Vtx;
}//End Insert_Steiner_Vertex_Release_Memory()
