int  *Temp_Vtx_Parent;
int  *Temp_Vtx_Depth;
int  *Quick_Index_List;

int  *Union_Index_After_Delete;
int  Index_Num_After_Delete;
int  *Union_Index_After_Add;
int  Index_Num_After_Add;
bool *If_Index_Covered;
int  *Temp_Union_Index;

bool **If_Swap_Feasible;

int  *Cur_Spanned_Vtx;
int  Cur_Spanned_Vtx_Num=0;
int  *Cur_Neighbor_Vtx;
int  Cur_Neighbor_Vtx_Num=0;

int *All_Vtx_SD;
int *Temp_Data_For_SD;

//Initialiaze the data structure used for swap-vtx move 
void Swap_Vertex_Init()
{
  Temp_Vtx_Parent=new int [Vtx_Num];
  Temp_Vtx_Depth=new int [Vtx_Num];
  Quick_Index_List=new int [Vtx_Num];

  Union_Index_After_Delete=new int [Vtx_Num];
  Union_Index_After_Add=new int [Vtx_Num];  
  If_Index_Covered=new bool [Vtx_Num];
  Temp_Union_Index=new int [Vtx_Num];

  If_Swap_Feasible=new bool *[Vtx_Num];
  for(int i=0;i<Vtx_Num;i++)
    If_Swap_Feasible[i]=new bool [Vtx_Num];
  
  Cur_Spanned_Vtx=new int [Vtx_Num];
  Cur_Neighbor_Vtx=new int [Vtx_Num];  
    
  All_Vtx_SD=new int [Vtx_Num];
  Temp_Data_For_SD=new int [Vtx_Num];  
}//End Swap_Vertex_Init

//Release the memory used for swap-vtx move
void Swap_Vertex_Release_Memory()
{ 
  delete []Temp_Vtx_Parent;
  delete []Temp_Vtx_Depth;
  delete []Quick_Index_List;

  delete []Union_Index_After_Delete;
  delete []Union_Index_After_Add;  
  delete []If_Index_Covered;
  delete []Temp_Union_Index;
  
  for(int i=0;i<Vtx_Num;i++)
    delete []If_Swap_Feasible[i];
  delete []If_Swap_Feasible;
  
  delete []Cur_Spanned_Vtx;
  delete []Cur_Neighbor_Vtx;  
  delete []All_Vtx_SD;
  delete []Temp_Data_For_SD;
}//End Swap_Vertex_Release_Memory()

bool Check_If_Neighbor_Vtx(Struct_Solution *Cur_Solution,int Cur_Vtx)
{
  if(Cur_Solution->If_Vtx_Spanned[Cur_Vtx])
    return false;
  
  for(int i=0;i<Vtx_Degree[Cur_Vtx];i++)
  {
    int Adj_Vtx=Adjacent_Vtx[Cur_Vtx][i];
    if(Cur_Solution->If_Vtx_Spanned[Adj_Vtx])    
      return true;
  }  
}

void Swap_Vtx_Prepare(Struct_Solution *Cur_Solution)
{
  Index_Num_After_Delete=0;
  Index_Num_After_Add=0;
  for(int i=0;i<Vtx_Num;i++)
  {
    Union_Index_After_Delete[i]=Null;  
    Union_Index_After_Add[i]=Null;
    If_Index_Covered[i]=false;
    Temp_Union_Index[i]=i;
  }
  
  Cur_Spanned_Vtx_Num=0;
  Cur_Neighbor_Vtx_Num=0;
  for(int i=0;i<Vtx_Num;i++)
    if(Cur_Solution->If_Vtx_Spanned[i])
    {
      Temp_Vtx_Parent[i]=Cur_Solution->Vtx_Parent[i]; 
      Temp_Vtx_Depth[i]=Get_Vtx_Depth(Cur_Solution,i);
      Quick_Index_List[i]=Cur_Solution->Root;
      Cur_Spanned_Vtx[Cur_Spanned_Vtx_Num++]=i;
    }
    else
    {
      Temp_Vtx_Parent[i]=Null;
      Temp_Vtx_Depth[i]=Null;
      Quick_Index_List[i]=i;  
      
      if(Check_If_Neighbor_Vtx(Cur_Solution,i))
        Cur_Neighbor_Vtx[Cur_Neighbor_Vtx_Num++]=i;
    }
       
  for(int i=0;i<Vtx_Num;i++)
    for(int j=0;j<Vtx_Num;j++)    
      If_Swap_Feasible[i][j]=false;  
}//End Swap_Vtx_Prepare()

bool Check_If_Index_Exist(int Union_Index_After_Delete[],int Index_Num_After_Delete,int Index_To_Check)
{
  for(int i=0;i<Index_Num_After_Delete;i++) 
    if(Union_Index_After_Delete[i]==Index_To_Check)
      return true;
  
  return false;
}//End Check_If_Index_Exist()

void Get_Union_Index_After_Delete(Struct_Solution *Cur_Solution,int Union_Find_Set[],int Vtx_To_Delete)
{  
  Index_Num_After_Delete=0;
  for(int i=0;i<Vtx_Degree[Vtx_To_Delete];i++)
  {
    int Temp_Adj_Vtx=Adjacent_Vtx[Vtx_To_Delete][i];  
    if(!Cur_Solution->If_Vtx_Spanned[Temp_Adj_Vtx])
      continue;
      
    int Temp_Index=Get_Union_Find_Index(Union_Find_Set,Temp_Adj_Vtx); 
    if(!Check_If_Index_Exist(Union_Index_After_Delete,Index_Num_After_Delete,Temp_Index))
      Union_Index_After_Delete[Index_Num_After_Delete++]=Temp_Index; 
  }                                        
}//End Get_Union_Index_After_Delete()

void Update_Quick_Index_List(Struct_Solution *Cur_Solution,int Cur_Depth)
{
  for(int i=0;i<Cur_Spanned_Vtx_Num;i++)
  {         
    int Cur_Vtx=Cur_Spanned_Vtx[i]; 
     
    if(!Cur_Solution->If_Vtx_Spanned[Cur_Vtx])
      Quick_Index_List[Cur_Vtx]=Cur_Vtx; 
    else if(Temp_Vtx_Depth[Cur_Vtx]<=Cur_Depth)
      Quick_Index_List[Cur_Vtx]=Cur_Solution->Root;
    else if(Temp_Vtx_Depth[Cur_Vtx]==Cur_Depth+1)
      Quick_Index_List[Cur_Vtx]=Cur_Vtx;
    else
    {
      int Cur_Index=Quick_Index_List[Cur_Vtx];
      while(Temp_Vtx_Depth[Cur_Index]>Cur_Depth+1)         
        Cur_Index=Temp_Vtx_Parent[Cur_Index]; 
      Quick_Index_List[Cur_Vtx]=Cur_Index;
    }
  }           
}//End Update_Quick_Index_List()

int Quickly_Get_Union_Index(Struct_Solution *Cur_Solution,int Removed_Vtx,int Cur_Vtx)
{  
  int Temp_Index=Quick_Index_List[Cur_Vtx];
  if(Temp_Index==Cur_Solution->Root)
    return Temp_Index;   
  
  if(Temp_Vtx_Parent[Temp_Index]!=Removed_Vtx)
    return Cur_Solution->Root;
  else     
    return Get_Union_Find_Index(Union_Find_Set,Temp_Index); 
}//End Get_Vtx_Union_Find_Index()

void Get_All_Union_Index(Struct_Solution *Cur_Solution,int Removed_Vtx)
{
  for(int i=0;i<Cur_Spanned_Vtx_Num;i++)
  {         
    int Cur_Vtx=Cur_Spanned_Vtx[i]; 
    if(!Cur_Solution->If_Vtx_Spanned[Cur_Vtx] || Cur_Vtx==Removed_Vtx)        
      Temp_Union_Index[Cur_Vtx]=Cur_Vtx;
    else      
      Temp_Union_Index[Cur_Vtx]=Quickly_Get_Union_Index(Cur_Solution,Removed_Vtx,Cur_Vtx);
  }
}//End Get_All_Vtx_Union_Find_Index()

//Get the different union find index connected to an added vtx
void Get_Covered_Union_Index_After_Add(Struct_Solution *Cur_Solution,int Vtx_To_Add)
{  
  Index_Num_After_Add=0;  
  for(int i=0;i<Vtx_Degree[Vtx_To_Add];i++)
  {
    int Adj_Vtx=Adjacent_Vtx[Vtx_To_Add][i];
    if(Cur_Solution->If_Vtx_Spanned[Adj_Vtx])    
      Union_Index_After_Add[Index_Num_After_Add++]=Temp_Union_Index[Adj_Vtx]; 
  }
}//End Get_Covered_Union_Index_After_Add()

bool Check_If_Swap_Vtx_Feasible(Struct_Solution *Cur_Solution,int Vtx_To_Remove,int Vtx_To_Add)
{  
  if(Cur_Solution->If_Vtx_Spanned[Vtx_To_Add] || Vtx_To_Remove==Vtx_To_Add)
    return false; 
      
  for(int i=0;i<Index_Num_After_Delete;i++) 
    If_Index_Covered[Union_Index_After_Delete[i]]=false; 
  
  Get_Covered_Union_Index_After_Add(Cur_Solution,Vtx_To_Add); 
  for(int i=0;i<Index_Num_After_Add;i++)    
    If_Index_Covered[Union_Index_After_Add[i]]=true; 
  
  for(int i=0;i<Index_Num_After_Delete;i++)  
    if(!If_Index_Covered[Union_Index_After_Delete[i]])    
      return false;
             
  return true;    
}//End Check_If_Swap_Feasible()

void Get_All_If_Swap_Vtx_Feasible(Struct_Solution *Cur_Solution)
{ 
  Copy_Solution(&Temp_Solution,Cur_Solution,1); 
  
  Swap_Vtx_Prepare(Cur_Solution); 
  
  Add_All_Vertical_Edge_To_LHeap(Cur_Solution);
  Add_All_Horizontal_Edge_To_List(Cur_Solution);  

  Update_Union_Find_Set(Union_Find_Set,Cur_Solution);
  Copy_Union_Find_Set(Union_Find_Set_Bak,Union_Find_Set);    

  int Pre_Vtx_Depth=Null;
  Spanned_Vtx_Num=Post_Order_Traverse_Solution(Cur_Solution);      
  for(int i=0;i<Spanned_Vtx_Num;i++)
  {         
    int Cur_Vtx=Post_Order_Vtx[i];   
    int Removed_Edge_Num=Remove_Vtx(Cur_Solution,Union_Find_Set,Cur_Vtx);      
    int Candidate_Edge_Num=Get_Candidate_Edge(Cur_Solution,Cur_Vtx);  
    Merge_Sub_LHeap(Cur_Vtx);   
    
    Kruskal_Repair_MST(Cur_Solution,Union_Find_Set,Candidate_Edge,Candidate_Edge_Num,Removed_Edge_Num-1);
    
    if(Pre_Vtx_Depth==Null || Temp_Vtx_Depth[Cur_Vtx]<Pre_Vtx_Depth)
    {
      Update_Quick_Index_List(Cur_Solution,Temp_Vtx_Depth[Cur_Vtx]);  
      Pre_Vtx_Depth=Temp_Vtx_Depth[Cur_Vtx];
    }    
    Get_All_Union_Index(Cur_Solution,Cur_Vtx);
    Get_Union_Index_After_Delete(Cur_Solution,Union_Find_Set,Cur_Vtx);
        
    for(int j=0;j<Cur_Neighbor_Vtx_Num;j++)
    {
      int Neighbor_Vtx=Cur_Neighbor_Vtx[j];
      
      if(Cur_Solution->If_Vtx_Spanned[Neighbor_Vtx])
        continue;
      
      If_Swap_Feasible[Cur_Vtx][Neighbor_Vtx]=Check_If_Swap_Vtx_Feasible(Cur_Solution,Cur_Vtx,Neighbor_Vtx);
    } 
      
    if(Delete_Changed_Vtx_Num<Vtx_Num)      
    {
      Part_Restore_Solution(Cur_Solution,&Temp_Solution,Delete_Changed_Vtx,Delete_Changed_Vtx_Num);      
      Part_Restore_Union_Find_Set(Union_Find_Set,Union_Find_Set_Bak,Delete_Changed_Vtx,Delete_Changed_Vtx_Num); 
    }       
    else
    {
      Copy_Solution(Cur_Solution,&Temp_Solution,1);
      Copy_Union_Find_Set(Union_Find_Set,Union_Find_Set_Bak);
    }    
  }//End for 

  Copy_Solution(Cur_Solution,&Temp_Solution,1);
}//End Get_All_If_Swap_Vtx_Feasible()

