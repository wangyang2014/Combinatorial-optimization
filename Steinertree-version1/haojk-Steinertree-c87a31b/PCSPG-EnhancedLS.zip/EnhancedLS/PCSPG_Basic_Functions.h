/*******************************************************************************
**This file includes a number of basic functions 
*******************************************************************************/
//Get a random number belonging to [0,Divide_Num) 
int Get_Random_Int(int Divide_Num)
{ 
  return rand()%Divide_Num;
}//End Get_Random_Int()

double Calculate_Error(double First_Number,double Second_Number)
{
  if(First_Number >= Second_Number)
    return First_Number-Second_Number;
  else
    return Second_Number-First_Number;
}

//Get the average cost of all the edges
double Get_Avg_Edge_Cost()
{
  double Total_Edge_Cost=0;
  for(int i=0;i<Selected_Edge_Num;i++) 
    Total_Edge_Cost+=(double)Selected_Edge[i].Cost; 
  
  return Total_Edge_Cost/Selected_Edge_Num;
}//End Get_Avg_Edge_Cost()

//Get the average difference of the edge cost of a given instance
double Get_Avg_Edge_Diff()
{
  double Total_Edge_Cost=0;
  for(int i=0;i<Selected_Edge_Num;i++) 
    Total_Edge_Cost+=(double)Selected_Edge[i].Cost; 
  
  double Avg_Edge_Cost=Total_Edge_Cost/Selected_Edge_Num;

  double Avg_Edge_Diff=0;
  for(int i=0;i<Selected_Edge_Num;i++)   
    Avg_Edge_Diff+=Calculate_Error(Selected_Edge[i].Cost,Avg_Edge_Cost)/Avg_Edge_Cost;

  Avg_Edge_Diff/=Selected_Edge_Num;
  
  return Avg_Edge_Diff;    
}//End Get_Avg_Edge_Diff()

void Record_Overall_Best_Solution(Struct_Solution *Cur_Solution)
{
  //Record the overall best found solution of a given instance                
  if(Get_Solution_Obj(Cur_Solution) < Overall_Best_Obj)
  {
    Overall_Best_Obj=Get_Solution_Obj(Cur_Solution);
    Stoerd_Improving_Slt_Obj[Overall_Improving_Slt_Num]=Get_Solution_Obj(Cur_Solution);
    Time_To_Find_Improving_Slt[Overall_Improving_Slt_Num]=((double)clock()-Search_Begin_Time)/CLOCKS_PER_SEC;    
    Overall_Improving_Slt_Num++;
    Copy_Solution(&Overall_Best_Solution,Cur_Solution,1);   
    Output_Solution_DIMACS(&Overall_Best_Solution,Output_File_Name); 
    Hit_Best_Times=1; 
  } 
  else if(Calculate_Error((double)Get_Solution_Obj(Cur_Solution),(double)Overall_Best_Obj)==0)
    Hit_Best_Times++; 
}
       
/*******************************************************************************
Functions related with shortest path between a pair of vertices
*******************************************************************************/

//Call Dijkstra algorithm (using a given binary heap) to calculate 
//the shortest path between a given source vtx and all the other vertices
bool Dijkstra_One_To_All(Binary_Heap *Temp_BHeap,Cost_Type *Temp_Shortest_Path_Cost,int Source_Vtx)
{ 
  //Prepare 
  Clear_Binary_Heap(Temp_BHeap);  
  bool If_Vtx_Connected[Vtx_Num];   
  for(int i=0;i<Vtx_Num;i++)
  {
    If_Vtx_Connected[i]=false;     
    Temp_Shortest_Path_Cost[i]=Edge_Cost[Source_Vtx][i];  
  }  
  If_Vtx_Connected[Source_Vtx]=true;
  
  //Init the binary heap to contain a number of candidate edges    
  for(int i=0;i<Vtx_Degree[Source_Vtx];i++)
  {    
    int Temp_Vtx=Adjacent_Vtx[Source_Vtx][i];    
    if(Edge_Cost[Source_Vtx][Temp_Vtx]<Inf_Cost)
      Binary_Heap_Add_Edge(Temp_BHeap,Source_Vtx,Temp_Vtx,Edge_Cost[Source_Vtx][Temp_Vtx]);
  } 

  int Min_Edge_Index=Null;   
  int Temp_First_Vtx=Null;
  int Temp_Second_Vtx=Null;
  int Base_Vtx=Null;
  int Vtx_To_Connect=Null; 
  
  //Repeatedly add a new edge, until all the vertices are connected 
  int Connected_Vtx_Num=1;
  while(Connected_Vtx_Num++<Vtx_Num)
  { 
    //Extract a valid edge with minimun cost 
    while(true)
    {
      Min_Edge_Index=Binary_Heap_Extract_Min_Edge(Temp_BHeap,Vtx_Num);    
      if(Min_Edge_Index==Null)
        return false;                        

      Temp_First_Vtx=Min_Edge_Index/Vtx_Num;
      Temp_Second_Vtx=Min_Edge_Index%Vtx_Num;
      if(!If_Vtx_Connected[Temp_First_Vtx])
      {
        Vtx_To_Connect=Temp_First_Vtx;
        Base_Vtx=Temp_Second_Vtx;        
        break;
      }
      
      if(!If_Vtx_Connected[Temp_Second_Vtx])
      {
        Vtx_To_Connect=Temp_Second_Vtx;
        Base_Vtx=Temp_First_Vtx;         
        break; 
      } 
    }//End while(true)
    
    //Add the selected edge   
    If_Vtx_Connected[Vtx_To_Connect]=true;
    Temp_Shortest_Path_Cost[Vtx_To_Connect]=Temp_Shortest_Path_Cost[Base_Vtx]+Edge_Cost[Base_Vtx][Vtx_To_Connect];
    
    //Update the binary heap with some new candidate edges 
    for(int i=0;i<Vtx_Degree[Vtx_To_Connect];i++)
    {
      int Temp_Vtx=Adjacent_Vtx[Vtx_To_Connect][i];       
      if(!If_Vtx_Connected[Temp_Vtx] && Edge_Cost[Vtx_To_Connect][Temp_Vtx]<Inf_Cost)
        Binary_Heap_Add_Edge(Temp_BHeap,Vtx_To_Connect,Temp_Vtx,
          Temp_Shortest_Path_Cost[Vtx_To_Connect]+Edge_Cost[Vtx_To_Connect][Temp_Vtx]);      
    }
  }//End while(Connected_Vtx_Num++<Vtx_Num) 

  return true;
}//End Dijkstra_One_To_All()

void Dijkstra_One_To_All(int Source_Vtx)
{
  Binary_Heap Temp_BHeap;  
  Creat_Binary_Heap(&Temp_BHeap,Edge_Num);
  
  Dijkstra_One_To_All(&Temp_BHeap,&Shortest_Path[Source_Vtx][0],Source_Vtx);   
  Delete_Binary_Heap(&Temp_BHeap);  
}//End Dijkstra_One_To_All()

//Using Dijkstra to calculate the shortest path between any pair of vertices
void Get_All_Pair_Shortest_Path()
{
  Binary_Heap Temp_BHeap;  
  Creat_Binary_Heap(&Temp_BHeap,Edge_Num); 
  
  for(int i=0;i<Vtx_Num;i++)
    Dijkstra_One_To_All(&Temp_BHeap,&Shortest_Path[i][0],i);

  Delete_Binary_Heap(&Temp_BHeap);
}//End Get_All_Pari_Shortest_Path();

int Stored_Path[Max_Path_Length];   //Used to store a shortest path
int Path_Length=0;                  //The length of the shortest path 

//Iteratively store the last vtx between Source_Vtx and Dest_Vtx
bool Iterative_Store_Last_Vtx(int Source_Vtx,int Dest_Vtx)
{    
  Stored_Path[Path_Length++]=Dest_Vtx;     
  if(Dest_Vtx==Source_Vtx)    
    return true;    
  
  for(int i=0;i<Vtx_Degree[Dest_Vtx];i++)     
  { 
    int Last_Vtx=Adjacent_Vtx[Dest_Vtx][i];       
    if(Calculate_Error(Shortest_Path[Source_Vtx][Last_Vtx]+Edge_Cost[Last_Vtx][Dest_Vtx], Shortest_Path[Source_Vtx][Dest_Vtx])<=Allowed_Error)
    {                         
      Iterative_Store_Last_Vtx(Source_Vtx,Last_Vtx);  
      break;      
    }  
  }  
     
  if(Path_Length>1 && Stored_Path[Path_Length-1]==Source_Vtx)
    return true;  
  else  
  {  
    printf("Iterative_Store_Last_Vtx() fail!Source_Vtx:%d Dest_Vtx:%d Path_Length:%d Stored_Path[]:%d\n",
            Source_Vtx+1,Dest_Vtx+1, Path_Length, Stored_Path[Path_Length-1]+1);
    if(If_Stop_At_Error)
      getchar();
    return false; 
  }      
}//End Iterative_Store_Last_Vtx()

//Get the shortest path between Source_Vtx and Dest_Vtx, stored in Stored_Path[]
bool Get_Real_Path(int Source_Vtx,int Dest_Vtx)
{ 
  if(Shortest_Path[Source_Vtx][Dest_Vtx]>=Inf_Cost)
    return false;
         
  Path_Length=0;
  if(Iterative_Store_Last_Vtx(Source_Vtx,Dest_Vtx)) 
    return true;       
  else 
  {
    printf("Get_Real_Path() Fail! From %d to %d\n",Source_Vtx+1,Dest_Vtx+1);    
    if(If_Stop_At_Error)
      getchar();
    return false;  
  }
}//End Get_Real_Path()

/*******************************************************************************
Functions related with kruskal algorithm 
*******************************************************************************/

//Initialize the union find set information
void Init_Union_Find_Set(int Union_Find_Set[])
{
  for(int i=0;i<Vtx_Num;i++)
    Union_Find_Set[i]=i;
}//End Init_Union_Find_Set()

//Update union find set according to the information of the a given solution
void Update_Union_Find_Set(int Union_Find_Set[],Struct_Solution *Cur_Solution)
{
  for(int i=0;i<Vtx_Num;i++)  
  {
    if(!Cur_Solution->If_Vtx_Spanned[i] || Cur_Solution->Vtx_Parent[i]==Null)
      Union_Find_Set[i]=i;
    else      
      Union_Find_Set[i]=Cur_Solution->Vtx_Parent[i];
  } 
}//End Update_Union_Find_Set()

//Get the union find index of a given vtx 
int Get_Union_Find_Index(int Union_Find_Set[],int Vtx_Index)
{
  int Cur_Vtx=Vtx_Index;
  int cnt=0;
  while(Union_Find_Set[Cur_Vtx]!=Cur_Vtx && Union_Find_Set[Cur_Vtx]!=Null && cnt++<Vtx_Num)    
    Cur_Vtx=Union_Find_Set[Cur_Vtx];    

  if(cnt>=Vtx_Num || Cur_Vtx==Null)
  {
    if(cnt>=Vtx_Num)
      printf("Get_Union_Find_Index() fail! A loop is detected, Vtx_Index:%d\n",Vtx_Index+1);
    if(Cur_Vtx==Null)
      printf("Get_Union_Find_Index() fail! The union find index of %d is null\n",Vtx_Index+1);
    
    if(If_Stop_At_Error)
      getchar();  
      
    return Null;               
  }
  
  return Cur_Vtx;
}//End Get_Union_Find_Index()

//Merge the union find set of two vertices 
bool Merge_Union_Find_Set(int Union_Find_Set[],int First_Vtx,int Second_Vtx)
{
  int First_Union_Find_Index=Get_Union_Find_Index(Union_Find_Set,First_Vtx);
  int Second_Union_Find_Index=Get_Union_Find_Index(Union_Find_Set,Second_Vtx);
  if(First_Union_Find_Index==Second_Union_Find_Index)
  {
    printf("Merge_Union_Find_Set() fail! The union find set of %d and %d is the same.\n",First_Vtx+1,Second_Vtx+1);   
    if(If_Stop_At_Error)
      getchar();
    return false;                                                  
  }
  
  Union_Find_Set[Second_Union_Find_Index]=First_Union_Find_Index;  
  return true;
}//End Merge_Union_Find_Set()

//Copy the union find set information from Source_Union_Find_Set[] to Dest_Union_Find_Set[]
void Copy_Union_Find_Set(int Dest_Union_Find_Set[],int Source_Union_Find_Set[])
{
  for(int i=0;i<Vtx_Num;i++)
    Dest_Union_Find_Set[i]=Source_Union_Find_Set[i];     
}//End Copy_Union_Find_Set()

//Patially restore the union find set infomation (only restored the information of changed vertices)
void Part_Restore_Union_Find_Set(int Dest_Union_Find_Set[],int Source_Union_Find_Set[],int Changed_Vtx[],int Changed_Vtx_Num)
{
  for(int i=0;i<Changed_Vtx_Num;i++)
    Dest_Union_Find_Set[Changed_Vtx[i]]=Source_Union_Find_Set[Changed_Vtx[i]];  
}//End Part_Restore_Union_Find_Set()

//Use kruskal algorithm to add a new edge, update the information of Added_Adjacent_Vtx[][], Vtx_Degree[] and Union_Find_Set[]
bool Kruskal_Add_Edge(Struct_Solution *Cur_Solution,int Union_Find_Set[],int First_Vtx,int Second_Vtx)
{ 
  if(Get_Union_Find_Index(Union_Find_Set,First_Vtx)==Get_Union_Find_Index(Union_Find_Set,Second_Vtx))
  {
    printf("Kruskal_Add_Edge() fail! The union find set index of %d and %d is the same.\n",First_Vtx+1,Second_Vtx+1);   
    if(If_Stop_At_Error)
      getchar();
    return false;                                                  
  }
 
  Cur_Solution->Added_Adjacent_Vtx[First_Vtx][Cur_Solution->Vtx_Degree[First_Vtx]]=Second_Vtx;
  Cur_Solution->Added_Adjacent_Vtx[Second_Vtx][Cur_Solution->Vtx_Degree[Second_Vtx]]=First_Vtx;
  Cur_Solution->Vtx_Degree[First_Vtx]++;
  Cur_Solution->Vtx_Degree[Second_Vtx]++;  
  Cur_Solution->Solution_Cost+=Edge_Cost[First_Vtx][Second_Vtx];
  
  Merge_Union_Find_Set(Union_Find_Set,First_Vtx,Second_Vtx);
  return true;
}//End Kruskal_Add_Edge()

bool Kruskal_Add_Edge(Struct_Solution *Cur_Solution, int Union_Find_Set[],int Added_Edge_Index)
{
  int First_Vtx=Selected_Edge[Added_Edge_Index].First_Vtx;
  int Second_Vtx=Selected_Edge[Added_Edge_Index].Second_Vtx;  
  return Kruskal_Add_Edge(Cur_Solution,Union_Find_Set,First_Vtx,Second_Vtx); 
}//End Kruskal_Add_Edge()

//Call kruskal algorithm to construct a minimum spanning tree
//The vertices to spanned are given by Cur_Solution->If_Vtx_Spanned[]
//The candidate edges are stored in Candidate_Edge[] in increasing order 
bool Kruskal_MST(Struct_Solution *Cur_Solution,int Union_Find_Set[], 
                 Struct_Edge Candidate_Edge[],int Candidate_Edge_Num,
                 bool If_Update_Solution)
{ 
  Format_Solution(Cur_Solution);
  Init_Union_Find_Set(Union_Find_Set);
  
  int Selected_Vtx_Num=0;
  for(int i=0;i<Vtx_Num;i++)
    if(Cur_Solution->If_Vtx_Spanned[i]) 
      Selected_Vtx_Num++;      

  int Added_Edge_Num=0;  
  for(int i=0;i<Candidate_Edge_Num;i++)
  {
    if(Added_Edge_Num>=Selected_Vtx_Num-1)  
    {
      Cur_Solution->If_Feasible=true;
      break; 
    } 
    
    int First_Vtx=Candidate_Edge[i].First_Vtx;
    int Second_Vtx=Candidate_Edge[i].Second_Vtx;
    if(Edge_Cost[First_Vtx][Second_Vtx]>=Inf_Cost)
      continue;
    if(!Cur_Solution->If_Vtx_Spanned[First_Vtx] || !Cur_Solution->If_Vtx_Spanned[Second_Vtx])
      continue; 
    if(Get_Union_Find_Index(Union_Find_Set,First_Vtx)==Get_Union_Find_Index(Union_Find_Set,Second_Vtx)) 
      continue;
      
    Kruskal_Add_Edge(Cur_Solution,Union_Find_Set,First_Vtx,Second_Vtx);    
    Added_Edge_Num++; 
  }  
  
  if(If_Update_Solution)
    Update_Solution(Cur_Solution);
          
  return Cur_Solution->If_Feasible;
}//End Kruskal_MST()

bool Kruskal_MST(Struct_Solution *Cur_Solution)
{
  return Kruskal_MST(Cur_Solution,Union_Find_Set,Selected_Edge,Selected_Edge_Num,true);
}

//Use kruskal algorithm to add a path (just update If_Vtx_Spanned[],Collected_Profit,Solution_Cost,Union_Find_Set[]) 
bool Kruskal_Add_Path(Struct_Solution *Cur_Solution,int Union_Find_Set[],int Source_Vtx,int Dest_Vtx)
{
  if(!Get_Real_Path(Source_Vtx,Dest_Vtx))
  {
    printf("Kruskal_Add_Path() fail! Fail to get a real path between %d and %d.\n",Source_Vtx+1,Dest_Vtx+1);   
    if(If_Stop_At_Error)
      getchar();
    return false; 
  }

  for(int i=0;i<Path_Length-1;i++)
  {
    int Cur_Vtx=Stored_Path[i];
    int Next_Vtx=Stored_Path[i+1];     
    if(!Cur_Solution->If_Vtx_Spanned[Cur_Vtx])
    { 
      Cur_Solution->If_Vtx_Spanned[Cur_Vtx]=true; 
      Cur_Solution->Collected_Profit+=Vtx_Profit[Cur_Vtx]; 
    } 
    
    if(!Cur_Solution->If_Vtx_Spanned[Next_Vtx])
    { 
      Cur_Solution->If_Vtx_Spanned[Next_Vtx]=true;
      Cur_Solution->Collected_Profit+=Vtx_Profit[Next_Vtx];
    } 
        
    if(Get_Union_Find_Index(Union_Find_Set,Cur_Vtx)!=Get_Union_Find_Index(Union_Find_Set,Next_Vtx))
    {        
      Cur_Solution->Solution_Cost+=Edge_Cost[Cur_Vtx][Next_Vtx]; 
      Merge_Union_Find_Set(Union_Find_Set,Cur_Vtx,Next_Vtx);
    } 
  } 
  
  return true; 
}//End Kruskal_Add_Path()

//Combine Kruskal_MST() with Kruskal_Add_Path() to consturct a feasible MST with any given set of vertices 
bool Kruskal_Hybrid_Construct_Solution (Struct_Solution *Cur_Solution,int Union_Find_Set[],
                                       Struct_Edge Candidate_Edge[],int Candidate_Edge_Num)
{
  //Try to construct a feasible MST by kruskal algorithm at first
  if(Kruskal_MST(Cur_Solution,Union_Find_Set,Candidate_Edge,Candidate_Edge_Num,true))  
    return true;  
  
  int Spanned_Vtx_Num=0;
  int Connected_Edge_Num=0; 
  for(int i=0;i<Vtx_Num;i++)
  {
    if(Cur_Solution->If_Vtx_Spanned[i])
    {
      Spanned_Vtx_Num++;  
      Connected_Edge_Num+=Cur_Solution->Vtx_Degree[i];                               
    }   
  }  
  Connected_Edge_Num/=2;  
  int Needed_Path_Num=Spanned_Vtx_Num-1-Connected_Edge_Num;
  int Added_Path_Num=0;
  
  //Add some new path (only record which vertices should be added), until a feasible solution could be constructed  
  int All_Path_Num=Vtx_Num*(Vtx_Num-1)/2;
  for(int i=0;i<All_Path_Num;i++)
  {
    if(Added_Path_Num>=Needed_Path_Num)
      break;
    int Source_Vtx=All_Shortest_Path[i].Source_Vtx;
    int Dest_Vtx=All_Shortest_Path[i].Dest_Vtx;
    
    if(!Cur_Solution->If_Vtx_Spanned[Source_Vtx] || !Cur_Solution->If_Vtx_Spanned[Dest_Vtx]       
       || Get_Union_Find_Index(Union_Find_Set,Source_Vtx)==Get_Union_Find_Index(Union_Find_Set,Dest_Vtx)) 
      continue;
 
    Kruskal_Add_Path(Cur_Solution,Union_Find_Set,Source_Vtx,Dest_Vtx); 
    Added_Path_Num++;
  } 
  
  //Use kruskal algorithm to reconstruct a MST, to span the original and newly added vertices 
  Kruskal_MST(Cur_Solution,Union_Find_Set,Candidate_Edge,Candidate_Edge_Num,true);
  
  Cur_Solution->If_Feasible=Check_Solution_Feasible(Cur_Solution);
  if(Cur_Solution->If_Feasible)   
    return true;
  else
  {
    printf("Kruskal_Hybrid_Construct_Solution() fail. The solution is unfeasible!\n");
    for(int i=0;i<Vtx_Num;i++)
      if(Cur_Solution->If_Vtx_Spanned[i])
        cout<<i+1<<":"<<Vtx_Profit[i]<<endl;
    if(If_Stop_At_Error)
      getchar();
    return false;                          
  }  
}//End Kruskal_Hybrid_Construct_Solution()

bool Kruskal_Hybrid_Construct_Solution(Struct_Solution *Cur_Solution)
{
  return Kruskal_Hybrid_Construct_Solution(Cur_Solution,Union_Find_Set,Selected_Edge,Selected_Edge_Num);     
}

/*******************************************************************************
**The following functions are used in SPH algorithm 
*******************************************************************************/

//Get the vtx of the current solution closest to a given vtx 
int Get_Path_Source_Vtx(Struct_Solution *Cur_Solution,int Vtx_To_Connect)
{
  if(Cur_Solution->If_Vtx_Spanned[Vtx_To_Connect]) 
    return Null;

  int Path_Source_Vtx=Null;
  Cost_Type Lowest_Cost=Inf_Cost;   
  for(int i=0;i<Vtx_Num;i++)
  {
    if(!Cur_Solution->If_Vtx_Spanned[i]) 
      continue;
    if(Shortest_Path[i][Vtx_To_Connect]<Lowest_Cost)
    {   
      Lowest_Cost=Shortest_Path[i][Vtx_To_Connect]; 
      Path_Source_Vtx=i;
    }       
  }  

  return Path_Source_Vtx;       
}//End Get_Path_Source_Vtx() 

//Get the cost of the shortest path from the current solution to a given vtx  
Cost_Type Get_Cost_To_Connect_Vtx(Struct_Solution *Cur_Solution,int Vtx_To_Connect)
{
  if(Cur_Solution->If_Vtx_Spanned[Vtx_To_Connect])   
    return 0;
     
  Cost_Type Lowest_Cost=Inf_Cost;   
  for(int i=0;i<Vtx_Num;i++)
  {
    if(!Cur_Solution->If_Vtx_Spanned[i]) 
      continue;
    if(Shortest_Path[i][Vtx_To_Connect]<Lowest_Cost)   
      Lowest_Cost=Shortest_Path[i][Vtx_To_Connect]; 
  }  
  
  return Lowest_Cost;       
}//End Get_Cost_To_Connect_Vtx() 

//Insert the vertices on the shortest path from Source_Vtx to Dest_Vtx to the current solution (let If_Vtx_Spanned[] be true) 
bool SPH_Insert_Path(Struct_Solution *Cur_Solution,int Source_Vtx,int Dest_Vtx)
{   
  if(!Get_Real_Path(Source_Vtx,Dest_Vtx))
    return false; 
  
  for(int i=0;i<Path_Length;i++)
    Cur_Solution->If_Vtx_Spanned[Stored_Path[i]]=true;
    
  return true;
}//End SPH_Insert_Path()

//Insert a new path to connect an uncollected vtx 
bool Connect_New_Vtx(Struct_Solution *Cur_Solution,int Vtx_To_Connect)
{
  int Path_Source_Vtx=Get_Path_Source_Vtx(Cur_Solution,Vtx_To_Connect);
  if(Path_Source_Vtx!=Null && SPH_Insert_Path(Cur_Solution,Path_Source_Vtx,Vtx_To_Connect))
    return true;
  else 
  {
    printf("\nConnect_New_Vtx() fail! Vtx_To_Connect:%d Path_Source_Vtx:%d\n",Vtx_To_Connect+1,Path_Source_Vtx+1);
    if(If_Stop_At_Error)
      getchar();
    return false;
  }
}//End Connect_New_Vtx()

//Randomly get the index of an unconnected profitable vtx which could improve the objective value
int Randomly_Get_Profitable_Vtx(Struct_Solution *Cur_Solution)
{
  int Begin_Index=Get_Random_Int(Vtx_Num); 
  Cost_Type Best_Cost=Inf_Cost;
  int Best_Vtx_To_Connect=Null;
  
  for(int i=0;i<Vtx_Num;i++)
  {
    int Cur_Vtx=(Begin_Index+i)%Vtx_Num; 
    if(Cur_Solution->If_Vtx_Spanned[Cur_Vtx] || Vtx_Profit[Cur_Vtx]==0)
      continue;
      
    Cost_Type Cost_To_Connect_Vtx=Get_Cost_To_Connect_Vtx(Cur_Solution,Cur_Vtx);   
    if(Cost_To_Connect_Vtx >= Inf_Cost)
      continue;
      
    //if(Cost_To_Connect_Vtx <= 1.2*Vtx_Profit[Cur_Vtx])
    if(Cost_To_Connect_Vtx <= Vtx_Profit[Cur_Vtx])
      return Cur_Vtx;
    
    /*
    if(Cost_To_Connect_Vtx-Vtx_Profit[Cur_Vtx]<Best_Cost && Get_Random_Int(100)<50)    
    {
       Best_Vtx_To_Connect=Cur_Vtx;       
       Best_Cost=Cost_To_Connect_Vtx-Vtx_Profit[Cur_Vtx];                       
    }
    */
  }    
  
  //if(Get_Random_Int(100)<50)
    //return Best_Vtx_To_Connect;
  //else  
    return Null;
}//End Randomly_Get_Profitable_Vtx()

//Randomly connect a profitable vtx to improve the objective value
bool Randomly_Connect_Profitable_Vtx(Struct_Solution *Cur_Solution)
{
  int Vtx_To_Connect=Randomly_Get_Profitable_Vtx(Cur_Solution);
  if(Vtx_To_Connect==Null)
    return false;
    
  if(Connect_New_Vtx(Cur_Solution,Vtx_To_Connect))  
    return true;
  else     
    return false;     
}//End andomly_Connect_Profitable_Vtx()

//Call SPH heuristic to randomly construct a feasible solution with a given root vtx
bool SPH_Random_Construct_Solution(Struct_Solution *Cur_Solution,int Root_Vtx)
{
  for(int i=0;i<Vtx_Num;i++)
    Cur_Solution->If_Vtx_Spanned[i]=false;

  Cur_Solution->If_Vtx_Spanned[Root_Vtx]=true; 
  
  Format_Solution(Cur_Solution); 

  //Iteratively connect a profitable vtx, until no further improvement could be acheived
  while(Randomly_Connect_Profitable_Vtx(Cur_Solution))
    ;

  //Call kruskal algorithm to construct a MST     
  Kruskal_MST(Cur_Solution);

  if(Check_Solution_Feasible(Cur_Solution))
    return true; 
  else
  {
    cout<<"SPH_Random_Construct_Solution() fail! The obtained solution is unfeasible!"<<endl;     
    if(If_Stop_At_Error)
      getchar();
    return false;
  }
}//End SPH_Random_Construct_Solution()

//Call SPH heuristic to randomly construct a feasible solution without a given root vtx unless in rooted version
bool SPH_Random_Construct_Solution(Struct_Solution *Cur_Solution)
{
  //For rooted version
  if(Fixed_Root != Null)
    return SPH_Random_Construct_Solution(Cur_Solution,Fixed_Root-1); 
    
  //For unrooted version, starting from a random vtx
  int Begin_Index=Get_Random_Int(Vtx_Num); 
  int Root_Vtx=Null;
  for(int i=0;i<Vtx_Num;i++)
  {
    Root_Vtx=(Begin_Index+i)%Vtx_Num;
    //if(Vtx_Profit[Root_Vtx]>0 && (Fixed_Root==Null || Shortest_Path[Root_Vtx][Fixed_Root-1]<Inf_Cost))
    if(Vtx_Profit[Root_Vtx]>0)
      break;    
  }
  
  if(Root_Vtx!=Null)
    return SPH_Random_Construct_Solution(Cur_Solution,Root_Vtx); 
  else
    return false;
}//End SPH_Random_Construct_Solution()

/*******************************************************************************
Functions related with a given solution 
*******************************************************************************/
int Get_Spanned_Vtx_Num(Struct_Solution *Cur_Solution)
{
  int Spanned_Vtx_Num=0;
  for(int i=0;i<Vtx_Num;i++)
    if(Cur_Solution->If_Vtx_Spanned[i])
       Spanned_Vtx_Num++;
       
  return Spanned_Vtx_Num;  
}//End Get_Spanned_Vtx_Num()

//Get the ancestor of a given vtx in the current solution (possibly unfeasible)
int Get_Vtx_Ancestor(Struct_Solution *Cur_Solution,int Vtx_Index)
{
  int Cur_Vtx=Vtx_Index;
  int cnt=0;  
  while(Cur_Solution->Vtx_Parent[Cur_Vtx]!=Null && Cur_Vtx!=Cur_Solution->Root && cnt++<Vtx_Num)
    Cur_Vtx=Cur_Solution->Vtx_Parent[Cur_Vtx];
  
  if(cnt>=Vtx_Num)
  {
    printf("Get_Vtx_Ancestor() fail. Loop is detected: %d",Vtx_Index+1);
    if(If_Stop_At_Error)
      getchar();
    return Null;
  }
  
  return Cur_Vtx;
}//End Get_Vtx_Ancestor()

//Get the depth of a given vtx in the current solution
int Get_Vtx_Depth(Struct_Solution *Cur_Solution,int Vtx_Index)
{
  if(!Cur_Solution->If_Vtx_Spanned[Vtx_Index])
    return Null;
    
  int Current_Vtx=Vtx_Index;
  int Vtx_Depth=1;
  while(Cur_Solution->Vtx_Parent[Current_Vtx]!=Null && Current_Vtx!=Cur_Solution->Root && Vtx_Depth<Vtx_Num)
  {
    Vtx_Depth++;
    Current_Vtx=Cur_Solution->Vtx_Parent[Current_Vtx];
  }
  
  if(Current_Vtx==Cur_Solution->Root)
    return Vtx_Depth;
  else
  {
    printf("Get_Vtx_Depth() fail. Vtx_Index:%d Vtx_Depth:%d\n",Vtx_Index+1,Vtx_Depth);
    if(If_Stop_At_Error)
      getchar();
    return Null;
  }
}// End Get_Vtx_Depth(Struct_Solution *Cur_Solution, int Vtx_Index)

//Get the shared root of two vertices in the current solution
int Get_Shared_Root(Struct_Solution *Cur_Solution,int First_Vtx,int Second_Vtx)
{
  int First_Vtx_Depth=Get_Vtx_Depth(Cur_Solution,First_Vtx);
  int Second_Vtx_Depth=Get_Vtx_Depth(Cur_Solution,Second_Vtx);
  
  if(First_Vtx_Depth==Null || Second_Vtx_Depth==Null)
  {
    printf("Get_Shared_Root() fail: %d %d\n",First_Vtx+1,Second_Vtx+1);
    if(If_Stop_At_Error)
      getchar();
    return Null;
  }  

  int Temp_First_Vtx=First_Vtx;
  int Temp_Second_Vtx=Second_Vtx;
  int cnt=0;
  if(First_Vtx_Depth>Second_Vtx_Depth) 
  {
    while(cnt++<First_Vtx_Depth-Second_Vtx_Depth) 
      Temp_First_Vtx=Cur_Solution->Vtx_Parent[Temp_First_Vtx];                               
  } 
  else if(Second_Vtx_Depth>First_Vtx_Depth)
  {
    while(cnt++<Second_Vtx_Depth-First_Vtx_Depth) 
      Temp_Second_Vtx=Cur_Solution->Vtx_Parent[Temp_Second_Vtx];   
  } 
   
  while(Temp_First_Vtx!=Temp_Second_Vtx)
  {
    Temp_First_Vtx=Cur_Solution->Vtx_Parent[Temp_First_Vtx];
    Temp_Second_Vtx=Cur_Solution->Vtx_Parent[Temp_Second_Vtx];  
  } 
  
  return Temp_First_Vtx;
}//End Get_Shared_Root()

//Check the feasibility of the current solution 
bool Check_Solution_Feasible(Struct_Solution *Cur_Solution)
{
  for(int i=0;i<Vtx_Num;i++)
  {
    if(Cur_Solution->If_Vtx_Spanned[i] && Get_Vtx_Ancestor(Cur_Solution,i)!=Cur_Solution->Root)
      return false;
  }
      
  return true;     
}//End Check_Solution_Feasible()

//Get the objective value (total cost) of a given solution
Cost_Type Get_Solution_Obj(Struct_Solution *Cur_Solution)
{ 
  if(Cur_Solution->If_Feasible)     
    return Cur_Solution->Solution_Cost+(Sum_Profit-Cur_Solution->Collected_Profit);
    //return Cur_Solution->Solution_Cost-Cur_Solution->Collected_Profit;
  else
  {
    printf("Get_Solution_Obj() fail. The current solution is unfeasible!\n");
    if(If_Stop_At_Error)
      getchar();
    return Inf_Cost;   
  }       
}//End Get_Solution_Obj() 

//Traverse the current solution in post order, stored in Post_Order_Vtx[], return the spanned vtx number
int Post_Order_Traverse_Solution(Struct_Solution *Cur_Solution,int Post_Order_Vtx[])
{
  if(!Cur_Solution->If_Feasible)
  {
    cout<<"Error! Post_Order_Traverse_Solution() fails. The current solution is unfeasible."<<endl;
    if(If_Stop_At_Error)
      getchar();
    return Null;                                 
  }
  
  for(int i=0;i<Vtx_Num;i++)
    Vtx_Child_Num[i]=0;
  
  int Spanned_Vtx_Num=0;  
  for(int i=0;i<Vtx_Num;i++)
  {
    if(i==Cur_Solution->Root)
      Spanned_Vtx_Num++;
    else if(Cur_Solution->Vtx_Parent[i]!=Null)
    {
      int Parent_Vtx=Cur_Solution->Vtx_Parent[i];
      Vtx_Children[Parent_Vtx][Vtx_Child_Num[Parent_Vtx]]=i;
      Vtx_Child_Num[Parent_Vtx]++; 
      Spanned_Vtx_Num++; 
    }     
  }
  
  if(Spanned_Vtx_Num==0)
    return Spanned_Vtx_Num;
    
  Post_Order_Vtx[Spanned_Vtx_Num-1]=Cur_Solution->Root;  
  
  int Begin_Index=Spanned_Vtx_Num-1;
  int End_Index=Spanned_Vtx_Num-2;
  while(End_Index<Begin_Index)
  {
    int Cur_Vtx=Post_Order_Vtx[Begin_Index];  
    for(int j=0;j<Vtx_Child_Num[Cur_Vtx];j++) 
      Post_Order_Vtx[End_Index--]=Vtx_Children[Cur_Vtx][j];
    
    Begin_Index--;                             
  }

  if(End_Index!=-1)
  {
    cout<<"Error! Post_Order_Traverse_Solution() fails. End index is wrong:"<<End_Index<<endl;
    if(If_Stop_At_Error)
      getchar();
    return Null;                 
  }

  return Spanned_Vtx_Num;     
}//End Post_Order_Traverse_Solution()

int Post_Order_Traverse_Solution(Struct_Solution *Cur_Solution)
{
  return Post_Order_Traverse_Solution(Cur_Solution,Post_Order_Vtx);
}//End Post_Order_Traverse_Solution()

//Copy Orign_Solution to Dest_Solution, Copy_Mode=0:partially copy, Copy_Mode=0:completely copy
void Copy_Solution(Struct_Solution *Dest_Solution,Struct_Solution *Orign_Solution,int Copy_Mode)
{
  for(int i=0;i<Vtx_Num;i++)
    Dest_Solution->If_Vtx_Spanned[i]=Orign_Solution->If_Vtx_Spanned[i];
  
  if(Copy_Mode==0)
    exit(0);
    
  for(int i=0;i<Vtx_Num;i++)
  { 
    Dest_Solution->Vtx_Parent[i]=Orign_Solution->Vtx_Parent[i];  
    Dest_Solution->Vtx_Degree[i]=Orign_Solution->Vtx_Degree[i]; 
  }   
  
  for(int i=0;i<Vtx_Num;i++)    
    for(int j=0;j<Vtx_Degree[i];j++)
      Dest_Solution->Added_Adjacent_Vtx[i][j]=Orign_Solution->Added_Adjacent_Vtx[i][j];
      
  Dest_Solution->Root=Orign_Solution->Root;
  Dest_Solution->Solution_Cost=Orign_Solution->Solution_Cost;
  Dest_Solution->Collected_Profit=Orign_Solution->Collected_Profit;
  Dest_Solution->If_Feasible=Orign_Solution->If_Feasible;   
}//End Copy_Solution()

void Copy_Solution(Struct_Solution *Dest_Solution,Struct_Solution *Orign_Solution)
{
  Copy_Solution(Dest_Solution,Orign_Solution,1); 
}
