#include "MWCS_IO.h"
#include "MWCS_Heap_Operations.h"
#include "MWCS_Basic_Functions.h"
#include "MWCS_Construct_Solution.h"
#include "MWCS_Insert_Vertex.h"
#include "MWCS_Delete_Vertex.h"
#include "MWCS_Swap_Vertex.h"
#include "MWCS_Local_Search.h"


int main(int argc, char ** argv)
{
  double Overall_Begin_Time=(double)clock();  
  Solve_Several_Instances(); 
  printf("\n\nFinished. Total time: %.2f\n",((double)clock()-Overall_Begin_Time)/CLOCKS_PER_SEC);   
  getchar();
  return 0;  
}

