/*******************************************************************************
****The following functions are used to dynamiclly insert a vertex
*******************************************************************************/

//Partially restore the current solution (only the changed vtx are restored) 
void Part_Restore_Solution(Struct_Solution *Dest_Solution,Struct_Solution *Orign_Solution,int Insert_Changed_Vtx[],int Insert_Changed_Vtx_Num)
{
  for(int i=0;i<Insert_Changed_Vtx_Num;i++)
  {
    int Vtx_To_Restore=Insert_Changed_Vtx[i];
    Dest_Solution->If_Vtx_Spanned[Vtx_To_Restore]=Orign_Solution->If_Vtx_Spanned[Vtx_To_Restore];
    Dest_Solution->Vtx_Parent[Vtx_To_Restore]=Orign_Solution->Vtx_Parent[Vtx_To_Restore]; 
  } 
  
  Dest_Solution->Root=Orign_Solution->Root;
  Dest_Solution->Solution_Cost=Orign_Solution->Solution_Cost;
  Dest_Solution->Collected_Profit=Orign_Solution->Collected_Profit;
  Dest_Solution->If_Feasible=Orign_Solution->If_Feasible; 
}//End Part_Restore_Solution()

Profit_Type *Insert_Vtx_Increased_Profit;

//Insert a new vtx to the solution, return the reduced cost
Cost_Type Get_Insert_Vtx_Increased_Profit(Struct_Solution *Cur_Solution,int Vtx_To_Insert)
{ 
  if(Cur_Solution->If_Vtx_Spanned[Vtx_To_Insert])  
    return -Inf_Cost; 

  bool If_Neighbor_Vtx=false;
  Profit_Type Increased_Profit=Vtx_Profit[Vtx_To_Insert];
  for(int i=0;i<Vtx_Degree[Vtx_To_Insert];i++)
  {
    int Vtx_To_Connect=Adjacent_Vtx[Vtx_To_Insert][i];
    if(Cur_Solution->If_Vtx_Spanned[Vtx_To_Connect]) 
      If_Neighbor_Vtx=true;      
    //else if(Vtx_Profit[Vtx_To_Connect]>0)
      //Increased_Profit+=Vtx_Profit[Vtx_To_Connect];      
  }

  if(If_Neighbor_Vtx)
    return Increased_Profit;
  else
    return -Inf_Cost;
}//End Get_Insert_Vtx_Increased_Profit()

//Get the reduced cost corresponding to inserting each vtx (using a dynamic and efficient method)
void Get_All_Insert_Vtx_Increased_Profit(Struct_Solution *Cur_Solution)
{  
  int Spanned_Vtx_Num=0;
  for(int i=0;i<Vtx_Num;i++)
    if(Cur_Solution->If_Vtx_Spanned[i])
      Spanned_Vtx_Num++;

  for(int i=0;i<Vtx_Num;i++) 
  {
    if(Spanned_Vtx_Num>0)
      Insert_Vtx_Increased_Profit[i]=Get_Insert_Vtx_Increased_Profit(Cur_Solution,i);
    else
      Insert_Vtx_Increased_Profit[i]=Vtx_Profit[i];
  }  
}//End Get_All_Insert_Vtx_Increased_Profit(Struct_Solution *Cur_Solution)

//Initialiaze the data structure used to insert Steiner vtx
void Insert_Vertex_Init()
{  
  Insert_Vtx_Increased_Profit=new Profit_Type[Vtx_Num];
}//End Insert_Vertex_Init()

//Release the memory used to insert Steiner vtx
void Insert_Vertex_Release_Memory()
{  
  delete []Insert_Vtx_Increased_Profit;  
}//End Insert_Vertex_Release_Memory()
