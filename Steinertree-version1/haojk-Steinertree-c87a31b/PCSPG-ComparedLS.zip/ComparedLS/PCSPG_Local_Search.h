
bool Basic_Insert_Delete_Move(Struct_Solution *Cur_Solution)        
{ 
  Cost_Type Cur_Solution_Cost=Get_Solution_Obj(Cur_Solution);
    
  Get_All_Insert_Vtx_Reduced_Cost(Cur_Solution);        
  Get_All_Delete_Vtx_Reduced_Cost(Cur_Solution);
    
  int Best_Candidte_Vtx=Null;  
  int Begin_Index=Get_Random_Int(Vtx_Num);
  for(int i=0;i<Vtx_Num;i++)
  {
    int Candidate_Vtx=(Begin_Index+i)%Vtx_Num;
    
    Cost_Type Reduecd_Cost;          
    if(!Cur_Solution->If_Vtx_Spanned[Candidate_Vtx])
      Reduecd_Cost=Insert_Vtx_Reduced_Cost[Candidate_Vtx];        
    else     
      Reduecd_Cost=Delete_Vtx_Reduced_Cost[Candidate_Vtx];   
      
    if(Reduecd_Cost > 0) 
    {      
      Best_Candidte_Vtx=Candidate_Vtx;  
      break;      
    }    
  }
    
  if(Best_Candidte_Vtx==Null) 
    return false;    

  if(Cur_Solution->If_Vtx_Spanned[Best_Candidte_Vtx])
    Cur_Solution->If_Vtx_Spanned[Best_Candidte_Vtx]=false;
  else
    Cur_Solution->If_Vtx_Spanned[Best_Candidte_Vtx]=true;         
  
  Kruskal_MST(Cur_Solution);
  return true;  
}//End Basic_Insert_Delete_Move()

bool Basic_Local_Search(Struct_Solution *Cur_Solution)
{
  Copy_Solution(&LS_Best_Solution,Cur_Solution,1);    
  Cost_Type Pre_Objective=Get_Solution_Obj(Cur_Solution);
  Cost_Type LS_Best_Objective=Pre_Objective;  
  while(((double)clock()-Search_Begin_Time)/CLOCKS_PER_SEC < Max_Allowed_Time)
  {    
    if(!Basic_Insert_Delete_Move(Cur_Solution))
      break;

    if(Get_Solution_Obj(Cur_Solution) < LS_Best_Objective)
    {
      Copy_Solution(&LS_Best_Solution,Cur_Solution,1);  
      LS_Best_Objective=Get_Solution_Obj(Cur_Solution);    
      Record_Overall_Best_Solution(Cur_Solution);         
    }       
  }//End while()  
  
  Copy_Solution(Cur_Solution,&LS_Best_Solution,1);

  if(!Cur_Solution->If_Feasible)
  {
    printf("Simple_Local_Search() fail. The obtained solution is unfeasible!\n");
    if(If_Stop_At_Error)
      getchar();
    return false;
  }  
  else if(Get_Solution_Obj(Cur_Solution)>=Pre_Objective)
    return false;
  else    
    return true;    
}//End Basic_Local_Search()

int Get_Vtx_SD(Struct_Solution *Cur_Solution,int Vtx_Index)
{    
  if(!Cur_Solution->If_Vtx_Spanned[Vtx_Index]) 
    return Null; 
    
  int Vtx_SD=0;
  for(int i=0;i<Vtx_Degree[Vtx_Index];i++)
  {
    int Adj_Vtx=Adjacent_Vtx[Vtx_Index][i];    
    if(Cur_Solution->If_Vtx_Spanned[Adj_Vtx])
      Vtx_SD++;            
  }
  
  return Vtx_SD;
}//End Get_Vtx_SD()

void Get_All_Vtx_SD(Struct_Solution *Cur_Solution)
{
  for(int i=0;i<Vtx_Num;i++)
    All_Vtx_SD[i]=Get_Vtx_SD(Cur_Solution,i);
}//End Get_All_Customer_SD()

int Get_Solution_SD(Struct_Solution *Cur_Solution)
{  
  int Solution_SD=0;
  for(int i=0;i<Vtx_Num;i++)
  {    
    if(Get_Vtx_SD(Cur_Solution,i)==1) 
      Solution_SD+=1;
  }

  return Solution_SD;  
}//Get_Solution_SD()

int Get_Insert_Vtx_Reduced_SD(Struct_Solution *Cur_Solution,int Vtx_To_Insert)
{  
  int Pre_SD=Get_Solution_SD(Cur_Solution);   
  Cur_Solution->If_Vtx_Spanned[Vtx_To_Insert]=true;    
  int Reduced_SD=Pre_SD-Get_Solution_SD(Cur_Solution);   
  Cur_Solution->If_Vtx_Spanned[Vtx_To_Insert]=false; 
  
  return Reduced_SD;          
}//End Get_Insert_Vtx_Reduced_SD()

int Quickly_Get_Insert_Vtx_Reduced_SD(Struct_Solution *Cur_Solution,int Vtx_To_Insert)
{   
  int Reduced_SD=0;  
  for(int i=0;i<Vtx_Degree[Vtx_To_Insert];i++) 
  {
    int Adj_Vtx=Adjacent_Vtx[Vtx_To_Insert][i];
    if(Cur_Solution->If_Vtx_Spanned[Adj_Vtx] && All_Vtx_SD[Adj_Vtx]==1)
      Reduced_SD++;
  }   
  
  int Spanned_Neighbor_Vtx_Num=0;
  for(int i=0;i<Vtx_Degree[Vtx_To_Insert];i++) 
  {
    int Adj_Vtx=Adjacent_Vtx[Vtx_To_Insert][i];    
    if(Cur_Solution->If_Vtx_Spanned[Adj_Vtx])
      Spanned_Neighbor_Vtx_Num++;
  } 
  
  if(Spanned_Neighbor_Vtx_Num==1)
    Reduced_SD--;

  return Reduced_SD; 
}//End Quickly_Get_Insert_Vtx_Reduced_SD()

int Get_Delete_Vtx_Reduced_SD(Struct_Solution *Cur_Solution,int Vtx_To_Romove)
{  
  int Pre_SD=Get_Solution_SD(Cur_Solution);   
  Cur_Solution->If_Vtx_Spanned[Vtx_To_Romove]=false;    
  int Reduced_SD=Pre_SD-Get_Solution_SD(Cur_Solution);   
  Cur_Solution->If_Vtx_Spanned[Vtx_To_Romove]=true; 
  
  return Reduced_SD;          
}//End Get_Remove_Vtx_Reduced_SD()

int Quickly_Get_Delete_Vtx_Reduced_SD(Struct_Solution *Cur_Solution,int Vtx_To_Romove)
{  
  int Reduced_SD=0;  
  for(int i=0;i<Vtx_Degree[Vtx_To_Romove];i++) 
  {
    int Adj_Vtx=Adjacent_Vtx[Vtx_To_Romove][i];
    if(Cur_Solution->If_Vtx_Spanned[Adj_Vtx] && All_Vtx_SD[Adj_Vtx]==2)
      Reduced_SD--;
  }
  
  if(All_Vtx_SD[Vtx_To_Romove]==1)
    Reduced_SD++;

  return Reduced_SD; 
}//End Quickly_Get_Delete_Vtx_Reduced_SD()

bool Enhanced_Insert_Delete_Move(Struct_Solution *Cur_Solution)        
{ 
  Get_All_Vtx_SD(Cur_Solution);
  Cost_Type Cur_Solution_Cost=Get_Solution_Obj(Cur_Solution);
    
  Get_All_Insert_Vtx_Reduced_Cost(Cur_Solution);        
  Get_All_Delete_Vtx_Reduced_Cost(Cur_Solution);
    
  int Best_Candidte_Vtx=Null;  
  int Begin_Index=Get_Random_Int(Vtx_Num);
  for(int i=0;i<Vtx_Num;i++)
  {
    int Candidate_Vtx=(Begin_Index+i)%Vtx_Num;
    
    Cost_Type Reduecd_Cost;       
    int Reduced_SD;
       
    if(!Cur_Solution->If_Vtx_Spanned[Candidate_Vtx])
    {
      Reduecd_Cost=Insert_Vtx_Reduced_Cost[Candidate_Vtx];  
      Reduced_SD=Quickly_Get_Insert_Vtx_Reduced_SD(Cur_Solution,Candidate_Vtx);
    }      
    else     
    {
      Reduecd_Cost=Delete_Vtx_Reduced_Cost[Candidate_Vtx];  
      Reduced_SD=Quickly_Get_Delete_Vtx_Reduced_SD(Cur_Solution,Candidate_Vtx);
    }      
    
    if(Reduecd_Cost > 0 || (Reduecd_Cost == 0 && Reduced_SD > 0))        
    {      
      Best_Candidte_Vtx=Candidate_Vtx;  
      break;      
    }    
  }
    
  if(Best_Candidte_Vtx==Null) 
    return false;    

  if(Cur_Solution->If_Vtx_Spanned[Best_Candidte_Vtx])
    Cur_Solution->If_Vtx_Spanned[Best_Candidte_Vtx]=false;
  else
    Cur_Solution->If_Vtx_Spanned[Best_Candidte_Vtx]=true;
          
  //Kruskal_Hybrid_Construct_Solution(Cur_Solution);
  Kruskal_MST(Cur_Solution);
  return true;  
}//End Enhanced_Insert_Delete_Move()

int Get_Swap_Vtx_Reduced_SD(Struct_Solution *Cur_Solution,int Vtx_To_Romove,int Vtx_To_Insert)
{  
  int Pre_SD=Get_Solution_SD(Cur_Solution); 
  
  Cur_Solution->If_Vtx_Spanned[Vtx_To_Romove]=false;
  Cur_Solution->If_Vtx_Spanned[Vtx_To_Insert]=true;
    
  int Reduced_SD=Pre_SD-Get_Solution_SD(Cur_Solution);  
       
  Cur_Solution->If_Vtx_Spanned[Vtx_To_Romove]=true;
  Cur_Solution->If_Vtx_Spanned[Vtx_To_Insert]=false; 
  
  return Reduced_SD;          
}//End Get_Swap_Vtx_Reduced_SD()

int Quickly_Get_Swap_Vtx_Reduced_SD(Struct_Solution *Cur_Solution,int Vtx_To_Romove,int Vtx_To_Insert)
{  
  for(int i=0;i<Vtx_Degree[Vtx_To_Romove];i++) 
    Temp_Data_For_SD[Adjacent_Vtx[Vtx_To_Romove][i]]=0; 
  
  for(int i=0;i<Vtx_Degree[Vtx_To_Insert];i++)
    Temp_Data_For_SD[Adjacent_Vtx[Vtx_To_Insert][i]]=0; 
    
  for(int i=0;i<Vtx_Degree[Vtx_To_Romove];i++) 
    Temp_Data_For_SD[Adjacent_Vtx[Vtx_To_Romove][i]]--; 

  for(int i=0;i<Vtx_Degree[Vtx_To_Insert];i++)
    Temp_Data_For_SD[Adjacent_Vtx[Vtx_To_Insert][i]]++; 

  int Reduced_SD=0;   
  for(int i=0;i<Vtx_Degree[Vtx_To_Romove];i++) 
  {
    int Adj_Vtx=Adjacent_Vtx[Vtx_To_Romove][i];
    if(Cur_Solution->If_Vtx_Spanned[Adj_Vtx] && Temp_Data_For_SD[Adj_Vtx]==-1 && All_Vtx_SD[Adj_Vtx]==2)
      Reduced_SD--;
  }
  
  if(All_Vtx_SD[Vtx_To_Romove]==1)
    Reduced_SD++; 
  
  for(int i=0;i<Vtx_Degree[Vtx_To_Insert];i++) 
  {
    int Adj_Vtx=Adjacent_Vtx[Vtx_To_Insert][i];
    if(Cur_Solution->If_Vtx_Spanned[Adj_Vtx] && Temp_Data_For_SD[Adj_Vtx]==1 && All_Vtx_SD[Adj_Vtx]==1)
      Reduced_SD++;
  } 
  
  int Spanned_Neighbor_Vtx_Num=0;
  for(int i=0;i<Vtx_Degree[Vtx_To_Insert];i++) 
  {
    int Adj_Vtx=Adjacent_Vtx[Vtx_To_Insert][i];    
    if(Adj_Vtx!=Vtx_To_Romove && Cur_Solution->If_Vtx_Spanned[Adj_Vtx])
      Spanned_Neighbor_Vtx_Num++;
  } 
  
  if(Spanned_Neighbor_Vtx_Num==1)
    Reduced_SD--; 

  return Reduced_SD; 
}//End Quickly_Get_Swap_Vtx_Reduced_SD()

bool Apply_Swap_Vtx_Move(Struct_Solution *Cur_Solution)        
{
  Get_All_Vtx_SD(Cur_Solution);
  
  int Best_First_Vtx=Null;
  int Best_Second_Vtx=Null;  
      
  int First_Begin_Index=Get_Random_Int(Vtx_Num);
  for(int i=0;i<Vtx_Num;i++)
  {
    int First_Vtx=(First_Begin_Index+i)%Vtx_Num;    
    if(!Cur_Solution->If_Vtx_Spanned[First_Vtx])   
      continue;
        
    int Second_Begin_Index=Get_Random_Int(Vtx_Num);
    for(int j=0;j<Vtx_Num;j++)
    {
      int Second_Vtx=(Second_Begin_Index+j)%Vtx_Num;      
      if(Cur_Solution->If_Vtx_Spanned[Second_Vtx])
        continue;  

      if(!If_Swap_Feasible[First_Vtx][Second_Vtx]) 
        continue;    
		
	  if(Local_Search_Mode==Run_Enhanced_Local_Search)
	  {	
	    int Swap_Vtx_Reduced_SD=Quickly_Get_Swap_Vtx_Reduced_SD(Cur_Solution,First_Vtx,Second_Vtx);                
        if(Vtx_Profit[Second_Vtx]>Vtx_Profit[First_Vtx] || (Vtx_Profit[Second_Vtx]==Vtx_Profit[First_Vtx] && Swap_Vtx_Reduced_SD > 0)) 
        {        
          Best_First_Vtx=First_Vtx;
          Best_Second_Vtx=Second_Vtx;         
          goto Apply_Swap_Move;                                          
        }
	  }   
	  else if(Local_Search_Mode==Run_Compared_Local_Search)  
	  {
	    if(Vtx_Profit[Second_Vtx]>Vtx_Profit[First_Vtx]) 
        {        
          Best_First_Vtx=First_Vtx;
          Best_Second_Vtx=Second_Vtx;         
          goto Apply_Swap_Move;                                          
        }	
	  } 
	       
    }       
  }    
  
  Apply_Swap_Move:
  if(Best_First_Vtx==Null || Best_Second_Vtx==Null)
    return false;

  Cost_Type Pre_Obj=Get_Solution_Obj(Cur_Solution);
  Cur_Solution->If_Vtx_Spanned[Best_First_Vtx]=false;
  Cur_Solution->If_Vtx_Spanned[Best_Second_Vtx]=true;   
   
  Kruskal_MST(Cur_Solution); 

  if(!Cur_Solution->If_Feasible)
  {
    printf("\nApply_Swap_Vtx_Move() fail! The solution after swapping %d and %d is unfeasible!\n",Best_First_Vtx,Best_Second_Vtx);   
    getchar();            
    return false;             
  }

  if(Get_Solution_Obj(Cur_Solution)<=Pre_Obj)
    return true;
  else
    return false;
}//End Apply_Swap_Vtx_Move()

bool Enhanced_Local_Search(Struct_Solution *Cur_Solution)
{
  Copy_Solution(&LS_Best_Solution,Cur_Solution,1);    
  Cost_Type Pre_Objective=Get_Solution_Obj(Cur_Solution);
  Cost_Type LS_Best_Objective=Pre_Objective;  
  while(((double)clock()-Search_Begin_Time)/CLOCKS_PER_SEC < Max_Allowed_Time)
  { 
    bool If_Insert_Delete_Success=false;
    if(Local_Search_Mode==Run_Enhanced_Local_Search)
      If_Insert_Delete_Success=Enhanced_Insert_Delete_Move(Cur_Solution);
    else if(Local_Search_Mode==Run_Compared_Local_Search)
	  If_Insert_Delete_Success=Basic_Insert_Delete_Move(Cur_Solution);
	   
    if(If_Insert_Delete_Success)
      ; 
    else 
    { 
      Get_All_If_Swap_Vtx_Feasible(Cur_Solution);                          
      bool If_Success=Apply_Swap_Vtx_Move(Cur_Solution);   
      if(!If_Success)  
        break; 
    }
    
    if(Get_Solution_Obj(Cur_Solution) < LS_Best_Objective)
    {
      Copy_Solution(&LS_Best_Solution,Cur_Solution,1);  
      LS_Best_Objective=Get_Solution_Obj(Cur_Solution);    
      Record_Overall_Best_Solution(Cur_Solution);         
    }       
  }//End while()  
  
  Copy_Solution(Cur_Solution,&LS_Best_Solution,1);

  if(!Cur_Solution->If_Feasible)
  {
    printf("Combined_Local_Search() fail. The obtained solution is unfeasible!\n");
    if(If_Stop_At_Error)
      getchar();
    return false;
  }  
  else if(Get_Solution_Obj(Cur_Solution)>=Pre_Objective)
    return false;
  else   
    return true;    
}//End Enhanced_Local_Search()

bool ILS(Struct_Solution *Cur_Solution)
{  
  SPH_Random_Construct_Solution(Cur_Solution);
  Record_Overall_Best_Solution(Cur_Solution);   
  Copy_Solution(&ILS_Best_Solution,Cur_Solution,1); 
  Cost_Type ILS_Best_Objective=Get_Solution_Obj(Cur_Solution);
  
  int Run_Times=0;
  Cost_Type Total_Solution_Objective=0;
  while(((double)clock()-Search_Begin_Time)/CLOCKS_PER_SEC < Max_Allowed_Time)  
  {
    SPH_Random_Construct_Solution(Cur_Solution);    
    
    if(Local_Search_Mode==Run_Basic_Local_Search)
    {
      Basic_Local_Search(Cur_Solution);
      Record_Overall_Best_Solution(Cur_Solution); 
      printf("\n\n After %d basic local search:%.2f  ",Run_Times,(double)Get_Solution_Obj(Cur_Solution));
    }    
    else if(Local_Search_Mode==Run_Enhanced_Local_Search || Local_Search_Mode==Run_Compared_Local_Search)
    {       
      Enhanced_Local_Search(Cur_Solution);
      Record_Overall_Best_Solution(Cur_Solution);
      printf("\n\n After %d enhanced local search:%.2f  ", Run_Times, (double)Get_Solution_Obj(Cur_Solution)); 
    }   
    
    Run_Times++;
    Total_Solution_Objective+=Get_Solution_Obj(Cur_Solution);
    printf("\n Current Obj:%.2f  Best Obj:%.2f      ", (double)Get_Solution_Obj(Cur_Solution),(double)ILS_Best_Objective);  
    
    //Record the best found solution               
    if(Get_Solution_Obj(Cur_Solution)<ILS_Best_Objective)
    {
      ILS_Best_Objective=Get_Solution_Obj(Cur_Solution);
      Copy_Solution(&ILS_Best_Solution,Cur_Solution,1);     
    }
  }//End while()   
  
  //Restore the best found solution 
  Copy_Solution(Cur_Solution,&ILS_Best_Solution,1);    
  Kruskal_Hybrid_Construct_Solution(Cur_Solution); 
  
  //Check the feasibility of the obtained solution  
  if(Check_Solution_Feasible(Cur_Solution))
  { 
    if(!If_Run_By_Script)   
      printf("\n The solution obtained by Swap_Vtx_Based_ILS() is:%.6f\n\n",(double)Get_Solution_Obj(Cur_Solution)); 
    
    FILE *fp; 
    fp = fopen(Log_File_Name, "a+");
    fprintf(fp, "\n%s\t  %.6f\t  %.6f\t  %d\t %.2f\t %.2f\n",Input_File_Name,(double)Get_Solution_Obj(Cur_Solution),Total_Solution_Objective/Run_Times,
                 Run_Times,Time_To_Find_Improving_Slt[Overall_Improving_Slt_Num-1],((double)clock()-Search_Begin_Time)/CLOCKS_PER_SEC);       
    fclose(fp); 
      
    return true;                                  
  }
  else
  {
    if(!If_Run_By_Script)
      cout<<"\n Swap_Vtx_Based_ILS(() fail! The solution obtained by Test_Swap_Vtx_Move() is unfeasible"<<endl;
    
    if(If_Stop_At_Error)
      getchar();
      
    return false;  
  } 
}//End ILS()

//Call the proposed algorithm to solve an instance
bool Solve_One_Instance()
{
  if(!If_Run_By_Script)
    cout<<"Begin to run instance "<<Input_File_Name<<endl;  
    
  if(!Read_Instance_Standard(Input_File_Name,Run_Mode))  
    return false;   
     
  Pre_Processing();  
  
  //Prepare  
  Create_Solution(&Incumbent_Solution);  
  Create_Solution(&LS_Best_Solution);
  Create_Solution(&ILS_Best_Solution);   
  Create_Solution(&Overall_Best_Solution);
  Create_Solution(&Temp_Solution); 

  Insert_Vertex_Init();
  Delete_Vertex_Init();
  Swap_Vertex_Init();  

  bool If_Success=ILS(&Incumbent_Solution);    
  Output_Solution_DIMACS(&Overall_Best_Solution,Output_File_Name);  

  Insert_Vertex_Release_Memory();
  Delete_Vertex_Release_Memory();
  Swap_Vertex_Release_Memory();  
  
  Delete_Solution(&Incumbent_Solution);   
  Delete_Solution(&LS_Best_Solution);
  Delete_Solution(&ILS_Best_Solution);   
  Delete_Solution(&Overall_Best_Solution);
  Delete_Solution(&Temp_Solution); 

  Release_Memory();  
  return If_Success;     
}//End Solve_One_Instance()

bool Solve_Several_Instances()
{ 
  ifstream FIC;
  FIC.open(Input_Inst_File_Name);  
  
  if(FIC.fail())
  {
    cout << "\n\nError! Fail to open file"<<Input_Inst_File_Name<<endl;
    getchar();
    return false;     
  }
  else
    cout << "\n\nRead instances information from "<<Input_Inst_File_Name<<endl;
    
  int Inst_Num;      
  FIC>>Inst_Num;     
  cout<<"Number of Instances: " <<Inst_Num <<endl;   
  
  for(int i=0;i<Inst_Num;i++)   
    FIC>>&Instance_Name[i][0];

  FIC.close();  
  
  FILE *fp; 
  fp = fopen(Log_File_Name, "w+");
  fprintf(fp, "Instance Name\t  Best Obj\t   Avrage Obj\t   Run Times\t  CPU time to best\t  Overall CPU Time\n\n");       
  fprintf(fp,"Instance number: %d\n",Inst_Num);
  fclose(fp);      
  
  for(int i=0;i<Inst_Num;i++)
  {
    Search_Begin_Time=(double)clock();
      
    strcpy(Input_File_Name,&Instance_Name[i][0]);      
    cout<<"\n\n\n\n\nInput file name:"<<Input_File_Name<<endl;    
    
    Set_Output_File_Name();    
    cout<<"\nOutput file name:"<<Output_File_Name<<endl;   
 
    Overall_Improving_Slt_Num=0;
    Overall_Best_Obj=Inf_Cost;
    for(int j=0;j<Max_Improving_Slt_Num;j++)
    {
      Stoerd_Improving_Slt_Obj[j]=Inf_Cost;
      Time_To_Find_Improving_Slt[j]=0;     
    } 
    
    Random_Seed=Default_Random_Seed;
    srand(Random_Seed);       
       
    if(!Solve_One_Instance())          
    {
      cout<<"Error!Fail to run instance "<<Input_File_Name<<endl;
      if(If_Stop_At_Error)
        getchar();
      continue;  
    }        
  }
   
  return true;
}//End Solve_Several_Instances() 
