
/******************************************************************************
This program is developed for solving the SPG, the PCSPG and the RPCST,
to run each problem, please set parameter Run_Mode to the corresponding mode
Version: 1.0

Authors: Zhang-Hua Fu and Jin-Kao Hao
Email: fu@info.univ-angers.fr  hao@info.univ-angers.fr 

All rights reserved @02 April 2015
*******************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string.h>
#include <time.h>
#include <ctime>
#include <vector>
#include <string.h>
#include <math.h>
using namespace std;

typedef double Profit_Type;
typedef double Cost_Type;

#define Run_SPG            0   
#define Run_PCSPG          1         
#define Run_RPCST          2         
#define Hybrid_Run_Mode    3          //Read PCSPG instance but run it as SPG
#define  Run_Basic_Local_Search    0
#define  Run_Enhanced_Local_Search  1
#define  Run_Compared_Local_Search  2

#define Max_Inst_Num     2000
#define Time_Div         CLOCKS_PER_SEC
#define Null             -1
#define Inf_Cost         1000000000
#define Default_Obj      Inf_Cost
#define Max_Path_Length  5000
#define Allowed_Error    0.01

int    Fixed_Root=Null;   
int    Run_Mode=Run_SPG; 
int    Local_Search_Mode=Run_Basic_Local_Search;

bool   If_Show_Detail=false;   
bool   If_Stop_At_Error=false;
bool   If_Run_By_Script=false;
double Max_Allowed_Time=3600;

//#define Default_Random_Seed  (unsigned)time(NULL);
#define Default_Random_Seed  1416150433;                            
unsigned Random_Seed=Default_Random_Seed;

#define  Max_Improving_Slt_Num  100000
int        Overall_Improving_Slt_Num=0;
Cost_Type  Overall_Best_Obj=Inf_Cost;
int        Hit_Best_Times=0;
Cost_Type  Stoerd_Improving_Slt_Obj[Max_Improving_Slt_Num];
double     Time_To_Find_Improving_Slt[Max_Improving_Slt_Num];

char *Input_Inst_File_Name="Instances-To-Run.txt";      //Using a file to store the instances to run
char *Log_File_Name="Log-Results.txt";                  //Log file
char Instance_Name[Max_Inst_Num][200];                  //The name of a series of instances
char Input_File_Name[100];                              //The file name of the input instance
char Output_File_Name[100];                             //The file name of the output result 
char Temp_Instance_Name[100];                           //The name of a temp file

//Information of a given edge 
struct Struct_Edge
{
  int First_Vtx;    
  int Second_Vtx;  
  Cost_Type Cost;
};

//Information of a given path from Source_Vtx to Dest_Vtx 
struct Struct_Path
{
  int Source_Vtx;       //Source vtx of the path
  int Dest_Vtx;         //Destination vtx of the path
  Cost_Type Path_Cost;  //Total cost of the path
};

//Information of the original graph
int Vtx_Num;                   //Vertices number 
int Edge_Num;                  //Edges number 

Profit_Type *Vtx_Profit;    //Profit of each vtx
Profit_Type  Sum_Profit;    //Sum profit of all the vertices 
Cost_Type **Edge_Cost;      //Cost of each edge, stored in a matrix 
Struct_Edge *All_Edge;      //All the edges, stored in Struct_Edge mode
Cost_Type **Shortest_Path;  //Cost of the shortest path between each pair of vertices 
Struct_Path *All_Shortest_Path;      //All the shortest paths, stored in Struct_Path mode 
 
Struct_Edge *Selected_Edge; //A subset of candidate edges which are useful
int Selected_Edge_Num;      //Number of the selected edges 

double Avg_Edge_Cost;       //Average of the edge cost
double Avg_Edge_Diff;       //Average difference of edge cost

int *Vtx_Degree;            //Degree of each vtx in the original graph
int **Adjacent_Vtx;         //Adjacent vertices of each vtx in the original graph
int Max_Adj_Vtx_Num=0;      //Upper bound of the adjacent vertices of a given vtx

//Information of a given solution 
struct Struct_Solution
{  
  bool *If_Vtx_Spanned;         //Record if a given vtx is spanned or not in the solution
  int  *Vtx_Parent;             //Record the parent vtx of a given vtx in the solution 
  int  *Vtx_Degree;             //Record the degree of a given vtx in the solution 
  int  **Added_Adjacent_Vtx;    //Record the adjacent vertices of a given vtx in the solution
   
  int  Root;                    //A special vtx is chosen as the root 
  Cost_Type Solution_Cost;      //Sum cost of the connected edges in the solution 
  Profit_Type Collected_Profit; //Sum profits of the spanned vertices in the solution
  bool If_Feasible;             //Indicate if the current solution is feasible 
};

int *Stored_Parent_Key_Vtx;  //Used to store the parent key vtx of each vtx
int *Root_Key_Vtx;           //Record the ancestor key vtx of each vtx in the current solution 
int *Union_Find_Set;         //Union find set information

//Needed to store some soltuion found by the algorithm 
Struct_Solution Incumbent_Solution;   //The current solution
Struct_Solution LS_Best_Solution;     //Best solution found by local search
Struct_Solution ILS_Best_Solution;    //Best solution found by iterated local search

Struct_Solution Temp_Solution;           //Used to store some temp solution
Struct_Solution LS_Temp_Solution;        //Used to store some temp solution in local search
Struct_Solution ILS_Temp_Solution;       //Used to store some temp solution in ILS

Struct_Solution Overall_Best_Solution;   //The overall best solution

//Used to update the current solution
int  *Checked_Vtx;                    //Used to store the vertices which have alreqdy been checked 
bool *If_Vtx_Checked;                 //Record if a vtx has been checked

//Used to traverse the current solution in post order 
int Spanned_Vtx_Num;                 //Number of the spanned vertices in the current solution 
int *Post_Order_Vtx;                 //Store all the spanned vertices in post order 
int *Vtx_Child_Num;                  //Children number of each vtx in the current solution  
int **Vtx_Children;                  //Used to store the children of each vtx in the current solution

//Record that if each vtx is selected to connect
bool *If_Customer_Selected;

//Related with swap Steiner move operator
bool **If_Swap_Steiner_Feasible;

Struct_Edge *Temp_Candidate_Edge;
int Temp_Candidate_Edge_Num;

int  *Temp_Union_Find_Set;
int  *Deleted_Vtx_Adj_Union_Find_Index;
int  Deleted_Union_Find_Index_Num;
int  *Added_Vtx_Adj_Union_Find_Index;
int  Added_Union_Find_Index_Num;
bool *If_Union_Find_Index_Covered;

int *Customer_Degree;
int *Steiner_Degree;

double Search_Begin_Time;

void Get_All_Pair_Shortest_Path(); 
bool Check_Solution_Feasible(Struct_Solution *Cur_Solution);
Cost_Type Get_Solution_Obj(Struct_Solution *Cur_Solution);
void Copy_Solution(Struct_Solution *Dest_Solution,Struct_Solution *Orign_Solution,int Copy_Mode);

double Get_Avg_Edge_Cost();
double Get_Avg_Edge_Diff();

/*******************************************************************************
**The following functions are used for input and output
*******************************************************************************/

//Creat a new solution and allocate memory to it 
void Create_Solution(Struct_Solution *New_Solution,int Max_Adj_Vtx_Num)
{   
  New_Solution->If_Vtx_Spanned=new bool [Vtx_Num];  
  New_Solution->Vtx_Parent=new int [Vtx_Num];
  New_Solution->Vtx_Degree=new int [Vtx_Num];  
  New_Solution->Added_Adjacent_Vtx=new int *[Vtx_Num];
  for(int i=0;i<Vtx_Num;i++)
    New_Solution->Added_Adjacent_Vtx[i]=new int [Max_Adj_Vtx_Num];  
    
  for(int i=0;i<Vtx_Num;i++)
  {
    New_Solution->If_Vtx_Spanned[i]=false;
    New_Solution->Vtx_Parent[i]=Null;
    New_Solution->Vtx_Degree[i]=0;          
  }
  
  for(int i=0;i<Vtx_Num;i++)
    for(int j=0;j<Max_Adj_Vtx_Num;j++)
      New_Solution->Added_Adjacent_Vtx[i][j]=Null;
  
  New_Solution->Root=Null;
  New_Solution->Solution_Cost=0;
  New_Solution->Collected_Profit=0; 
  New_Solution->If_Feasible=false;      
}//End Create_Solution()

void Create_Solution(Struct_Solution *New_Solution)
{
  Create_Solution(New_Solution,Max_Adj_Vtx_Num);  
}

//Delete a solution and release the occupied memory
void Delete_Solution(Struct_Solution *Solution_To_Delete)
{
  delete [] Solution_To_Delete->If_Vtx_Spanned; 
  delete [] Solution_To_Delete->Vtx_Parent;
  delete [] Solution_To_Delete->Vtx_Degree;

  for(int i=0;i<Vtx_Num;i++)
    delete [] Solution_To_Delete->Added_Adjacent_Vtx[i];
  delete [] Solution_To_Delete->Added_Adjacent_Vtx; 
  //delete Solution_To_Delete;  
}//End Delete_Solution()

//Fomat the information of a given solution: If_Vtx_Spanned[] remain unchanged
void Format_Solution(Struct_Solution *Cur_Solution)
{ 
  if(Fixed_Root==Null)    
    Cur_Solution->Root=Null;
  else
  {
    Cur_Solution->If_Vtx_Spanned[Fixed_Root-1]=true;
    Cur_Solution->Root=Fixed_Root-1;
  }
  
  Cur_Solution->Solution_Cost=0;    
  Cur_Solution->Collected_Profit=0;   
  Cur_Solution->If_Feasible=false;  
  
  for(int i=0;i<Vtx_Num;i++)
  {    
    Cur_Solution->Vtx_Parent[i]=Null;
    Cur_Solution->Vtx_Degree[i]=0;
    if(Cur_Solution->If_Vtx_Spanned[i])
      Cur_Solution->Collected_Profit+=Vtx_Profit[i];     
  }   
}//End Format_Solution()

//Update the information of Vtx_Parent[],Root,Solution_Cost,Collected_Profit,If_Feasible
//according to the information of If_Vtx_Spanned[],Vtx_Degree[],Added_Adjacent_Vtx[][]
bool Update_Solution(Struct_Solution *Cur_Solution)
{
  //Update the root vtx
  if(Fixed_Root != Null)  
  {
    if(Cur_Solution->If_Vtx_Spanned[Fixed_Root-1])     
      Cur_Solution->Root=Fixed_Root-1;
    else
    {
      printf("Update_Solution() fail! The fixed root %d is not spanned!\n",Fixed_Root);    
      if(If_Stop_At_Error)
        getchar();
      return false;
    }
  }
  else  
  {
    Cur_Solution->Root=Null; 
    for(int i=0;i<Vtx_Num;i++)    
      if(Cur_Solution->If_Vtx_Spanned[i] && (Cur_Solution->Root==Null || Vtx_Profit[i] >  Vtx_Profit[Cur_Solution->Root]))    
        Cur_Solution->Root=i;      
    
    if(Cur_Solution->Root==Null)
    {
      Cur_Solution->Solution_Cost=0;
      Cur_Solution->Collected_Profit=0;
      Cur_Solution->If_Feasible=true;
      for(int i=0;i<Vtx_Num;i++)
        Cur_Solution->Vtx_Parent[i]=Null; 
          
      return true;
    }  
  }//Fix root vtx finished
  
  //Prepare   
  for(int i=0;i<Vtx_Num;i++)
  {    
    Checked_Vtx[i]=Null;
    If_Vtx_Checked[i]=false;       
  }  

  //Update Vtx_Parent[] information
  for(int i=0;i<Vtx_Num;i++)
    Cur_Solution->Vtx_Parent[i]=Null; 
    
  int Begin_Index=0;
  int End_Index=0;
  Checked_Vtx[End_Index++]=Cur_Solution->Root;  
  If_Vtx_Checked[Cur_Solution->Root]=true;  
  while(Begin_Index<End_Index)
  {
    int Parent_Vtx=Checked_Vtx[Begin_Index];    
    int Parent_Vtx_Degree=Cur_Solution->Vtx_Degree[Parent_Vtx];
    for(int i=0;i<Parent_Vtx_Degree;i++)
    {
      int Child_Vtx=Cur_Solution->Added_Adjacent_Vtx[Parent_Vtx][i];
      if(Child_Vtx==Null)
        return false;
      if(!If_Vtx_Checked[Child_Vtx])
      {        
        Checked_Vtx[End_Index++]=Child_Vtx;
        If_Vtx_Checked[Child_Vtx]=true;
        Cur_Solution->Vtx_Parent[Child_Vtx]=Parent_Vtx;                                    
      }      
    }  
    Begin_Index++;                            
  } 
  
  //Update Solution_Cost and Collected_Profit information
  Cur_Solution->Solution_Cost=0;
  Cur_Solution->Collected_Profit=0;
  for(int i=0;i<Vtx_Num;i++)
  {
    if(Cur_Solution->If_Vtx_Spanned[i]) 
    {
      Cur_Solution->Collected_Profit+=Vtx_Profit[i];
      if(Cur_Solution->Vtx_Parent[i]!=Null)   
        Cur_Solution->Solution_Cost+=Edge_Cost[i][Cur_Solution->Vtx_Parent[i]];                            
    }            
  }

  //Check if the current solution is feasible 
  Cur_Solution->If_Feasible=Check_Solution_Feasible(Cur_Solution);
  return Cur_Solution->If_Feasible;
}//End Update_Solution()

//Display the information of the current solution 
void Print_Solution(Struct_Solution *Cur_Solution, int Display_Mode)
{
  if(!Cur_Solution->If_Feasible) 
  {
    cout<<"Print_Solution() fail! The current solution is unfeasible!"<<endl;
    getchar();
    exit(0);                             
  }

  cout<<"Root:"<<Cur_Solution->Root+1<<endl<<endl;
  cout<<"The following vertices are spanned"<<endl;  
  for(int i=0;i<Vtx_Num;i++)
    if(Cur_Solution->If_Vtx_Spanned[i])
      cout<<i+1<<"-"<<Vtx_Profit[i]<<" ";
  cout<<endl;  

  if(Display_Mode>0)
  {
    cout<<"The following edges are connected."<<endl; 
    for(int i=0;i<Vtx_Num;i++)
      if(Cur_Solution->Vtx_Parent[i]!=Null)
        cout<<i+1<<"->"<<Cur_Solution->Vtx_Parent[i]+1<<":"<<Edge_Cost[i][Cur_Solution->Vtx_Parent[i]]<<endl; 
  }
  
  cout<<"Sum Profit:"<<Sum_Profit<<endl;
  cout<<"Collected Profit:"<<Cur_Solution->Collected_Profit<<endl;
  cout<<"Consumed Cost:"<<Cur_Solution->Solution_Cost<<endl;
  cout<<"Objective value:"<<Get_Solution_Obj(Cur_Solution)<<endl; 
  cout<<"The current solution is feasible"<<endl<<endl;    
}//End Print_Solution() 

//Allocate the needed memory and initialize the data structures
void Allocate_Memory(int Vtx_Num,int Edge_Num)
{
  if(!If_Run_By_Script)
    cout<<"Begin to allocate memory, Vtx_Num: "<<Vtx_Num<<"  Edge_Num:"<<Edge_Num<<endl;

  Vtx_Profit = new Profit_Type [Vtx_Num];
  for(int i=0;i<Vtx_Num;i++)
    Vtx_Profit[i]=0; 

  Edge_Cost = new Cost_Type *[Vtx_Num];
  for(int i=0;i<Vtx_Num;i++)
    Edge_Cost[i]=new Cost_Type [Vtx_Num];   

  for(int i=0;i<Vtx_Num;i++)
    for(int j=0;j<Vtx_Num;j++)
    {
      if(i==j)
        Edge_Cost[i][j]=0;
      else
        Edge_Cost[i][j]=(Cost_Type)Inf_Cost;
    }

  All_Edge=new Struct_Edge [Edge_Num];
  for(int i=0;i<Edge_Num;i++)
  {
    All_Edge[i].First_Vtx=Null;
    All_Edge[i].Second_Vtx=Null;
    All_Edge[i].Cost=Null;    
  }

  Shortest_Path=new Cost_Type *[Vtx_Num];
  for(int i=0;i<Vtx_Num;i++)
    Shortest_Path[i]=new Cost_Type [Vtx_Num];     
  
  for(int i=0;i<Vtx_Num;i++)
    for(int j=0;j<Vtx_Num;j++)
    {
      if(i==j)
        Shortest_Path[i][j]=0;
      else
        Shortest_Path[i][j]=(Cost_Type)Inf_Cost;
    }
      
  int Shortest_Path_Num=Vtx_Num*(Vtx_Num-1)/2;
  All_Shortest_Path=new Struct_Path[Shortest_Path_Num]; 
  for(int i=0;i<Shortest_Path_Num;i++)
  {
    All_Shortest_Path[i].Source_Vtx=Null;     
    All_Shortest_Path[i].Dest_Vtx=Null;
    All_Shortest_Path[i].Path_Cost=Null;
  }   
  
  Selected_Edge_Num=Edge_Num;   
  Selected_Edge=new Struct_Edge [Selected_Edge_Num];
  for(int i=0;i<Selected_Edge_Num;i++)
  {
    Selected_Edge[i].First_Vtx=Null;
    Selected_Edge[i].Second_Vtx=Null;
    Selected_Edge[i].Cost=Null;    
  } 

  Vtx_Degree = new int [Vtx_Num];
  for(int i=0;i<Vtx_Num;i++)
    Vtx_Degree[i]=0; 
     
  Adjacent_Vtx=new int *[Vtx_Num];
  for(int i=0;i<Vtx_Num;i++)
    Adjacent_Vtx[i]=new int [Vtx_Num];  
   
  for(int i=0;i<Vtx_Num;i++)
    for(int j=0;j<Vtx_Num;j++)  
      Adjacent_Vtx[i][j]=Null;
      
  Stored_Parent_Key_Vtx=new int [Vtx_Num];
  for(int i=0;i<Vtx_Num;i++)
    Stored_Parent_Key_Vtx[i]=Null; 
    
  Root_Key_Vtx=new int [Vtx_Num]; 
  for(int i=0;i<Vtx_Num;i++)
    Root_Key_Vtx[i]=Null; 
            
  Union_Find_Set=new int [Vtx_Num];
  for(int i=0;i<Vtx_Num;i++)
    Union_Find_Set[i]=i;
    
  Checked_Vtx=new int [Vtx_Num];
  If_Vtx_Checked=new bool [Vtx_Num]; 
  for(int i=0;i<Vtx_Num;i++)
  {
    Checked_Vtx[i]=Null;
    If_Vtx_Checked[i]=false;    
  }
  
  Spanned_Vtx_Num=0;  
  Post_Order_Vtx=new int [Vtx_Num];
  Vtx_Child_Num=new int [Vtx_Num];
  Vtx_Children=new int *[Vtx_Num];
  for(int i=0;i<Vtx_Num;i++)
    Vtx_Children[i]=new int [Vtx_Num];
  
  for(int i=0;i<Vtx_Num;i++)
  {
    Post_Order_Vtx[i]=Null;
    Vtx_Child_Num[i]=0;
    for(int j=0;j<Vtx_Num;j++)
      Vtx_Children[i][j]=Null;
  }      

  //Related with swap Steiner move
  If_Swap_Steiner_Feasible=new bool *[Vtx_Num];
  for(int i=0;i<Vtx_Num;i++)
    If_Swap_Steiner_Feasible[i]=new bool [Vtx_Num]; 
    
  for(int i=0;i<Vtx_Num;i++)
    for(int j=0;j<Vtx_Num;j++)
      If_Swap_Steiner_Feasible[i][j]=false;

  Temp_Candidate_Edge_Num=Edge_Num;   
  Temp_Candidate_Edge=new Struct_Edge [Temp_Candidate_Edge_Num];
  for(int i=0;i<Temp_Candidate_Edge_Num;i++)
  {
    Temp_Candidate_Edge[i].First_Vtx=Null;
    Temp_Candidate_Edge[i].Second_Vtx=Null;
    Temp_Candidate_Edge[i].Cost=Null;    
  } 
 
  Temp_Union_Find_Set=new int [Vtx_Num];
  Deleted_Vtx_Adj_Union_Find_Index=new int [Vtx_Num];
  Added_Vtx_Adj_Union_Find_Index=new int [Vtx_Num];
  If_Union_Find_Index_Covered=new bool [Vtx_Num];
  for(int i=0;i<Vtx_Num;i++)
  {
    Temp_Union_Find_Set[i]=Null;
    Deleted_Vtx_Adj_Union_Find_Index[i]=Null;
    Added_Vtx_Adj_Union_Find_Index[i]=Null; 
    If_Union_Find_Index_Covered[i]=false;     
  }
  Deleted_Union_Find_Index_Num=0;
  Added_Union_Find_Index_Num=0; 
  
  Customer_Degree=new int [Vtx_Num];
  Steiner_Degree=new int [Vtx_Num];
  for(int i=0;i<Vtx_Num;i++)
  {
    Customer_Degree[i]=Null;
    Steiner_Degree[i]=Null;     
  }   
   
  if(!If_Run_By_Script)
    cout<<"Allocate memory finished"<<endl;
}//End Allocate_Memory()

//Release the occupied memeory 
void Release_Memory()
{
  if(!If_Run_By_Script)
    cout<<"Begin to release memory"<<endl;
  
  delete []Vtx_Profit;  
   
  for(int i=0;i<Vtx_Num;i++)
    delete []Edge_Cost[i];
  delete []Edge_Cost;  
  delete []All_Edge; 
    
  for(int i=0;i<Vtx_Num;i++)
    delete []Shortest_Path[i];
  delete []Shortest_Path;  
  delete []All_Shortest_Path;

  delete []Selected_Edge; 
  
  delete []Vtx_Degree;  
  for(int i=0;i<Vtx_Num;i++)
    delete []Adjacent_Vtx[i];
  delete []Adjacent_Vtx;     
  
  delete []Stored_Parent_Key_Vtx;
  delete []Root_Key_Vtx;
  delete []Union_Find_Set;
  
  delete []Checked_Vtx;
  delete []If_Vtx_Checked; 

  delete []Post_Order_Vtx;
  delete []Vtx_Child_Num;
  for(int i=0;i<Vtx_Num;i++)
    delete []Vtx_Children[i];
  delete []Vtx_Children; 
  
  //Related with swap Steiner move
  for(int i=0;i<Vtx_Num;i++)
    delete []If_Swap_Steiner_Feasible[i];
  delete []If_Swap_Steiner_Feasible;

  delete []Temp_Candidate_Edge;
  
  delete []Temp_Union_Find_Set;
  delete []Deleted_Vtx_Adj_Union_Find_Index;
  delete []Added_Vtx_Adj_Union_Find_Index;
  delete []If_Union_Find_Index_Covered;
  delete []Customer_Degree;
  delete []Steiner_Degree;  
  
  if(!If_Run_By_Script)
    cout<<"Release memory finished"<<endl; 
}//End Release_Memory()

//Save all edges 
void Save_All_Edge()
{
  Edge_Num=0;
  for(int i=0;i<Vtx_Num;i++)
    for(int j=i+1;j<Vtx_Num;j++)  
    {
      if(Edge_Cost[i][j]<Inf_Cost) 
      {
        All_Edge[Edge_Num].First_Vtx=i;      
        All_Edge[Edge_Num].Second_Vtx=j;
        All_Edge[Edge_Num].Cost=Edge_Cost[i][j];   
        Edge_Num++;                        
      }               
    }   
}//End Save_All_Edge()

//Select all edges as candidate edges 
void Select_All_Edge()
{
  for(int i=0;i<Edge_Num;i++)
  {
    Selected_Edge[i].First_Vtx=All_Edge[i].First_Vtx;      
    Selected_Edge[i].Second_Vtx=All_Edge[i].Second_Vtx;
    Selected_Edge[i].Cost=All_Edge[i].Cost;    
  } 
  Selected_Edge_Num=Edge_Num; 
}//End Select_All_Edge()

//Merge edge array from Second_List to First_List
void Merge_Edge_Array(Struct_Edge *First_List,int First_List_Size,Struct_Edge *Second_List,int Second_List_Size)
{
  int i,j,k;
  i=j=k=0;
 
  //Use temp edge list to store the edges     
  Struct_Edge *Temp_List;
  Temp_List=new Struct_Edge [First_List_Size+Second_List_Size];
 
  //Repeat the following operations until one array reaches the end
  while(i<First_List_Size && j<Second_List_Size)
  {    
    if(First_List[i].Cost<=Second_List[j].Cost)
    {   
      Temp_List[k].First_Vtx=First_List[i].First_Vtx;
      Temp_List[k].Second_Vtx=First_List[i].Second_Vtx;
      Temp_List[k].Cost=First_List[i].Cost;      
      k++;
      i++;
    }
    else
    {
      Temp_List[k].First_Vtx=Second_List[j].First_Vtx;
      Temp_List[k].Second_Vtx=Second_List[j].Second_Vtx;
      Temp_List[k].Cost=Second_List[j].Cost;      
      k++;
      j++;
    }
  }

  while(i<First_List_Size)
  {
    Temp_List[k].First_Vtx=First_List[i].First_Vtx;
    Temp_List[k].Second_Vtx=First_List[i].Second_Vtx;
    Temp_List[k].Cost=First_List[i].Cost;
    k++;
    i++;    
  }

  while (j<Second_List_Size)
  {
    Temp_List[k].First_Vtx=Second_List[j].First_Vtx;
    Temp_List[k].Second_Vtx=Second_List[j].Second_Vtx;
    Temp_List[k].Cost=Second_List[j].Cost;    
    k++;
    j++;
  }
 
  //Copy the sorted edges to the first list
  for(int cnt=0;cnt<(First_List_Size+Second_List_Size);++cnt)
  {
    First_List[cnt].First_Vtx=Temp_List[cnt].First_Vtx;
    First_List[cnt].Second_Vtx=Temp_List[cnt].Second_Vtx;
    First_List[cnt].Cost=Temp_List[cnt].Cost;
  }
    
  delete []Temp_List; 
}//End Merge_Edge_Array()

//Merge sort a numbers of edges in increasing order
bool Merge_Inc_Sort_Edge(Struct_Edge *Edge_List,int List_Size)
{
  if(List_Size>1)
  {    
    Struct_Edge *First_List=Edge_List;
    int First_List_Size=List_Size/2;
    Struct_Edge *Second_List=Edge_List+List_Size/2;
    int Second_List_Size=List_Size-First_List_Size;
    
    Merge_Inc_Sort_Edge(First_List,First_List_Size);
    Merge_Inc_Sort_Edge(Second_List,Second_List_Size); 
    
    Merge_Edge_Array(First_List,First_List_Size,Second_List,Second_List_Size);
  }
  
  for(int i=0;i<List_Size-1;i++)
    if(Edge_List[i].Cost>Edge_List[i+1].Cost)
    {
      printf("Merge_Inc_Sort_Edge() fail! %d %d: %d %d\n",i+1,i+2,Edge_List[i].Cost,Edge_List[i+1].Cost); 
      if(If_Stop_At_Error)
        getchar();
      return false;                                        
    }
    
  return true;  
}//End Merge_Inc_Sort_Edge

//Save the cost of all the shortest paths to All_Shortest_Path[] 
void Save_All_Path()
{
  int Path_Index=0;
  for(int i=0;i<Vtx_Num;i++)
    for(int j=i+1;j<Vtx_Num;j++)  
    { 
      All_Shortest_Path[Path_Index].Source_Vtx=i;      
      All_Shortest_Path[Path_Index].Dest_Vtx=j;
      All_Shortest_Path[Path_Index].Path_Cost=Shortest_Path[i][j];   
      Path_Index++;                   
    }   
}//End Save_All_Path()

//Merge path array from Second_List to First_List
void Merge_Path_Array(Struct_Path *First_List,int First_List_Size,Struct_Path *Second_List,int Second_List_Size)
{
  int i,j,k;
  i=j=k=0;
 
  //Use temp path list to store the paths   
  Struct_Path *Temp_List;
  Temp_List=new Struct_Path [First_List_Size+Second_List_Size];
 
  //Repeat the following operations until one array reaches the end
  while(i<First_List_Size && j<Second_List_Size)
  {    
    if(First_List[i].Path_Cost<=Second_List[j].Path_Cost)
    {   
      Temp_List[k].Source_Vtx=First_List[i].Source_Vtx;
      Temp_List[k].Dest_Vtx=First_List[i].Dest_Vtx;
      Temp_List[k].Path_Cost=First_List[i].Path_Cost;
      k++;
      i++;      
    }
    else
    {
      Temp_List[k].Source_Vtx=Second_List[j].Source_Vtx;
      Temp_List[k].Dest_Vtx=Second_List[j].Dest_Vtx;
      Temp_List[k].Path_Cost=Second_List[j].Path_Cost;
      k++;
      j++;      
    }
  }

  while(i<First_List_Size)
  {
    Temp_List[k].Source_Vtx=First_List[i].Source_Vtx;
    Temp_List[k].Dest_Vtx=First_List[i].Dest_Vtx;
    Temp_List[k].Path_Cost=First_List[i].Path_Cost;
    k++;
    i++;    
  }

  while(j<Second_List_Size)
  {
    Temp_List[k].Source_Vtx=Second_List[j].Source_Vtx;
    Temp_List[k].Dest_Vtx=Second_List[j].Dest_Vtx;
    Temp_List[k].Path_Cost=Second_List[j].Path_Cost;
    k++;
    j++;    
  }
     
  //Copy the sorted paths to the first list
  for(int cnt=0;cnt<(First_List_Size+Second_List_Size);++cnt)
  {
    First_List[cnt].Source_Vtx=Temp_List[cnt].Source_Vtx;
    First_List[cnt].Dest_Vtx=Temp_List[cnt].Dest_Vtx;
    First_List[cnt].Path_Cost=Temp_List[cnt].Path_Cost;
  }
    
  delete []Temp_List; 
}//End Merge_Path_Array()

//Merge sort a numbers of paths in increasing order
bool Merge_Inc_Sort_Path(Struct_Path *Path_List,int List_Size)
{
  if(List_Size>1)
  {    
    Struct_Path *First_List=Path_List;
    int First_List_Size=List_Size/2;
    Struct_Path *Second_List=Path_List+List_Size/2;
    int Second_List_Size=List_Size-First_List_Size;
    
    Merge_Inc_Sort_Path(First_List,First_List_Size);
    Merge_Inc_Sort_Path(Second_List,Second_List_Size);
 
    Merge_Path_Array(First_List,First_List_Size,Second_List,Second_List_Size);
  }
  
  for(int i=0;i<List_Size-1;i++)
    if(Path_List[i].Path_Cost>Path_List[i+1].Path_Cost)
    {
      printf("Merge_Sort_Path() fail! %d %d: %d %d\n",i+1,i+2,Path_List[i].Path_Cost,Path_List[i+1].Path_Cost); 
      if(If_Stop_At_Error)
        getchar();
      return false;                                        
    }
    
  return true;  
}//End Merge_Sort_Path

//Get Vtx_Degree[] and Adjacent_Vtx[][] information of the original graph, return the upper bound of adjacent vertices number
int Get_Vtx_Degree_and_Adjacent_Vtx()
{
  for(int i=0;i<Vtx_Num;i++)
    Vtx_Degree[i]=0;
    
  for(int i=0;i<Vtx_Num;i++)
    for(int j=0;j<Vtx_Num;j++)
      Adjacent_Vtx[i][j]=Null;
    
  for(int i=0;i<Vtx_Num;i++)
    for(int j=0;j<Vtx_Num;j++)
    {
      if(j!=i && Edge_Cost[i][j]<Inf_Cost)
      {        
        Adjacent_Vtx[i][Vtx_Degree[i]]=j;
        Vtx_Degree[i]++;                                 
      }                
    }
    
  int Max_Adj_Vtx_Num=0;
  for(int i=0;i<Vtx_Num;i++) 
    if(Vtx_Degree[i]>Max_Adj_Vtx_Num)
      Max_Adj_Vtx_Num=Vtx_Degree[i];
  
  return Max_Adj_Vtx_Num;
}//End Get_Vtx_Degree_and_Adjacent_Vtx() 

//Read the input data of a given instance in standard format
bool Read_Instance_Standard(char *Input_File_Name,int Run_Mode)
{
  ifstream FIC;   
  FIC.open(Input_File_Name);   
   
  if (FIC.fail())
  {     
    cout<<"Read_Instance() fail! Fail to open the input file "<<Input_File_Name<<endl;
    if(If_Stop_At_Error)
      getchar();
    return false;     
  }
   
  char Str_Reading[100];
  int cnt=0;
  while(strcmp(Str_Reading,"Nodes") && cnt++ < 100) 
    FIC >> Str_Reading;

  if(cnt >= 100)
  {
    cout<<"Error! The format of the input file is wrong. "<<Input_File_Name<<endl;
    if(If_Stop_At_Error)
      getchar();
    return false;
  }

  FIC >> Vtx_Num;
  FIC >> Str_Reading;
  FIC >> Edge_Num;
  
  Allocate_Memory(Vtx_Num,Edge_Num);  
  
  int First_Vtx;
  int Second_Vtx;  
  double Temp_Cost;
  
  Cost_Type Total_Cost=0;
  for(int i=0;i<Edge_Num;i++)
  {
    FIC >> Str_Reading;
    FIC >> First_Vtx;
    FIC >> Second_Vtx;
    FIC >> Temp_Cost;   
    
    Edge_Cost[First_Vtx-1][Second_Vtx-1]=(Cost_Type)Temp_Cost;
    Edge_Cost[Second_Vtx-1][First_Vtx-1]=(Cost_Type)Temp_Cost; 
    Total_Cost+=Edge_Cost[First_Vtx-1][Second_Vtx-1];     
    //printf("Edge %d %d: %.6f\n",First_Vtx,Second_Vtx,(double)Edge_Cost[First_Vtx-1][Second_Vtx-1]);     
  }

  FIC >> Str_Reading;
  FIC >> Str_Reading;
  FIC >> Str_Reading;
  FIC >> Str_Reading;
  
  Sum_Profit=0;     
  int Terminal_Num;
  FIC >> Terminal_Num;  
  
  int Vtx_Index;  
  double Temp_Profit;
  
  //if(Fixed_Root!=Null)  
  if(Run_Mode==Run_RPCST) 
  {
    FIC >> Str_Reading;  
    FIC >> Vtx_Index; 
    Terminal_Num--;    
 
    if(Fixed_Root!=Null)
    {
      Fixed_Root=Vtx_Index;
      Vtx_Profit[Fixed_Root-1]=(Profit_Type)Inf_Cost/10;   
      Sum_Profit+=Vtx_Profit[Fixed_Root-1];   
    }
    else
    {
      Vtx_Profit[Vtx_Index-1]=(Profit_Type)Inf_Cost/10;   
      Sum_Profit+=Vtx_Profit[Vtx_Index-1];  
    }
  }
  
  for(int i=0;i<Terminal_Num;i++)
  {
    FIC >> Str_Reading;  
    FIC >> Vtx_Index;
    if(Run_Mode==Run_SPG)
      Temp_Profit=Inf_Cost/10;
    else if(Run_Mode==Run_PCSPG || Run_Mode==Run_RPCST)
      FIC >> Temp_Profit;    
    else if(Run_Mode==Hybrid_Run_Mode)
    {
      FIC >> Temp_Profit;       
      Temp_Profit*=10000; 
    }
    
    Vtx_Profit[Vtx_Index-1]=(Profit_Type)Temp_Profit;    
    Sum_Profit+=Vtx_Profit[Vtx_Index-1];    
  }  
  
  FIC.close();  
  if(!If_Run_By_Script)
    cout<<"Read instance finished. Begin to search. "<<endl<<endl;
  //getchar();
  return true;  
}//End Read_Instance_Standard()

void Pre_Processing()
{  
  Max_Adj_Vtx_Num=Get_Vtx_Degree_and_Adjacent_Vtx(); 
  
  Get_All_Pair_Shortest_Path(); 
  //Floyd_Warshall();

  Save_All_Edge();  
  Merge_Inc_Sort_Edge(All_Edge,Edge_Num);
  Select_All_Edge();  

  Save_All_Path();   
  int Path_Num=Vtx_Num*(Vtx_Num-1)/2; 
  Merge_Inc_Sort_Path(All_Shortest_Path,Path_Num);  
  
  Avg_Edge_Cost=Get_Avg_Edge_Cost();
  Avg_Edge_Diff=Get_Avg_Edge_Diff();
  
  if(!If_Run_By_Script)
    cout<<"Pre_Processing finished!"<<endl;    
  //getchar();
}

//Set the output file name according to the instance class and index information
bool Set_Output_File_Name()
{      
  int len=0;
  while((Input_File_Name[len]!='.' || Input_File_Name[len+1]!='s') && len<100)
  {
    Output_File_Name[len]=Input_File_Name[len]; 
    len++;
  } 
  
  if(len >= 100)
  {
    cout<<"Set_Output_File_Name() fail!"<<endl;     
    if(If_Stop_At_Error)
      getchar();
    return false;  
  } 

  Output_File_Name[len++]='.';
  Output_File_Name[len++]='t';
  Output_File_Name[len++]='x';      
  Output_File_Name[len++]='t';
  Output_File_Name[len++]='\0';  

  return true;      
}// End Set_Output_File_Name()

//Output a solution to file Output_File_Name
bool Output_Solution_DIMACS(Struct_Solution *Cur_Solution,char *Output_File_Name)
{
  Update_Solution(Cur_Solution);
  if(!Check_Solution_Feasible(Cur_Solution))
  {
    cout<<"\nThe incumbent solution is unfeasible, fail to save it to file "<<Output_File_Name<<endl;  
    if(If_Stop_At_Error)
      getchar();
      
    return false;                          
  }   

  if(!If_Run_By_Script)
    printf("\nOutput solution to file:%s Objective value:%.6f\n\n",Output_File_Name,(double)Get_Solution_Obj(Cur_Solution));  
  
  FILE *fp; 
  fp=fopen(Output_File_Name, "w+"); 
  
  fprintf(fp,"SECTION Comment\n");
  fprintf(fp,"Name \"%s\"\n",Input_File_Name);
  
  if(Run_Mode==Run_SPG || Run_Mode==Hybrid_Run_Mode)
  {
    fprintf(fp,"Problem \"SPG\"\n");
    fprintf(fp,"Program \"ILS-SPG\"\n");
  }
  else if(Run_Mode==Run_PCSPG)
  {
    fprintf(fp,"Problem \"PCSPG\"\n");
    fprintf(fp,"Program \"ILS-PCSPG\"\n");
  }
  else if(Run_Mode==Run_RPCST)
  {
    fprintf(fp,"Problem \"RPCST\"\n");
    fprintf(fp,"Program \"ILS-RPCST\"\n");
  }
  
  fprintf(fp,"Version 1.0\n");
  fprintf(fp,"Authors \"Zhang-Hua Fu and Jin-Kao Hao\"\n");
  fprintf(fp,"End\n\n");
      
  fprintf(fp,"SECTION Solutions\n");
  for(int i=0;i<Overall_Improving_Slt_Num;i++)
    fprintf(fp,"Solution   %.2f   %.6f\n",Time_To_Find_Improving_Slt[i],(double)Stoerd_Improving_Slt_Obj[i]);
  fprintf(fp,"End\n\n");
  
  fprintf(fp,"SECTION Run\n");
  fprintf(fp,"Threads 1\n");
  fprintf(fp,"Time    %.2f\n",((double)clock()-Search_Begin_Time)/CLOCKS_PER_SEC);
  fprintf(fp,"Primal  %.6f\n",(double)Get_Solution_Obj(Cur_Solution));
  fprintf(fp,"End\n\n");
  
  int Spanned_Vtx_Num=0;  
  for(int i=0;i<Vtx_Num;i++)
  {
    if(Cur_Solution->If_Vtx_Spanned[i])
      Spanned_Vtx_Num++;  
  }
    
  fprintf(fp,"SECTION Finalsolution\n");
  fprintf(fp,"Vertices %d\n",Spanned_Vtx_Num);
  for(int i=0;i<Vtx_Num;i++)
  {
    if(Cur_Solution->If_Vtx_Spanned[i])    
      fprintf(fp, "V %d\n",i+1);     
  }
     
  fprintf(fp,"\nEdges %d\n",Spanned_Vtx_Num-1);
  for(int i=0;i<Vtx_Num;i++)
  {
    if(Cur_Solution->If_Vtx_Spanned[i] && i!=Cur_Solution->Root)
      fprintf(fp, "E %d %d\n",i+1,Cur_Solution->Vtx_Parent[i]+1);  
  }
  fprintf(fp,"End\n\n"); 
  fclose(fp) ;
  return true;  
}//End Output_Solution_DIMACS()
