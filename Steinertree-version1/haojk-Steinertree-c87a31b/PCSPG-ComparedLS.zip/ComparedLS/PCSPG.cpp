#include "PCSPG_IO.h"
#include "PCSPG_Heap_Operations.h"
#include "PCSPG_Basic_Functions.h"
#include "PCSPG_Insert_Vertex.h"
#include "PCSPG_Delete_Vertex.h"
#include "PCSPG_Swap_Vertex.h"
#include "PCSPG_Local_Search.h"

int main(int argc, char ** argv)
{
  double Overall_Begin_Time=(double)clock();  
  Solve_Several_Instances(); 
  printf("\n\nFinished, press any key to stop. Total time: %.2f\n",((double)clock()-Overall_Begin_Time)/CLOCKS_PER_SEC);   
  getchar();
  return 0;  
}
